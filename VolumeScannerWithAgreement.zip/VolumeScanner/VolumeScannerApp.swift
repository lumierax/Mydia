import SwiftUI

@main
struct VolumeScannerApp: App {
    @Environment(\.scenePhase) private var scenePhase
    @StateObject private var market = MarketStore()
    @StateObject private var breakouts = BreakoutStore()

    var body: some Scene {
        WindowGroup {
            TabView {
                ScannerHome()
                    .tabItem {
                        Label("الفوليوم", systemImage: "chart.bar.fill")
                    }

                BreakoutsHome()
                    .tabItem {
                        Label("الاختراقات", systemImage: "arrow.up.right.circle.fill")
                    }

                AgreementHome()
                    .tabItem {
                        Label("التوافق", systemImage: "checkmark.seal.fill")
                    }
            }
            .environmentObject(market)
            .environmentObject(breakouts)
            .environment(\.layoutDirection, .rightToLeft)
            .tint(ScanTheme.accent)
            .toolbarBackground(ScanTheme.panel, for: .tabBar)
            .toolbarBackground(.visible, for: .tabBar)
            .preferredColorScheme(.dark)
            .onAppear {
                if scenePhase == .active {
                    market.start()
                    breakouts.resumeAuto()
                }
            }
            .onChange(of: scenePhase) { _, phase in
                if phase == .active {
                    market.start()
                    breakouts.resumeAuto()
                } else {
                    market.pause()
                    breakouts.pause()
                }
            }
        }
    }
}

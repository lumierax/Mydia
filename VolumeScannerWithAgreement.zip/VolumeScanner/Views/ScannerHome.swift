import SwiftUI

enum ScanTheme {
    static let background = Color(red: 0.035, green: 0.065, blue: 0.108)
    static let panel = Color(red: 0.064, green: 0.105, blue: 0.157)
    static let panelRaised = Color(red: 0.087, green: 0.139, blue: 0.195)
    static let line = Color(red: 0.16, green: 0.23, blue: 0.29)
    static let ink = Color(red: 0.94, green: 0.97, blue: 1.0)
    static let muted = Color(red: 0.56, green: 0.66, blue: 0.73)
    static let accent = Color(red: 0.23, green: 0.88, blue: 0.77)
    static let negative = Color(red: 1.0, green: 0.40, blue: 0.48)
}

private enum ActiveTable: String {
    case watch, shortlist
}

struct ScannerHome: View {
    @EnvironmentObject private var market: MarketStore
    @Environment(\.scenePhase) private var scenePhase
    @State private var selected: ActiveTable = .watch
    @State private var showClearConfirmation = false

    var body: some View {
        ZStack {
            ScanTheme.background.ignoresSafeArea()
            RadialGradient(
                colors: [ScanTheme.accent.opacity(0.11), .clear],
                center: .topTrailing,
                startRadius: 10,
                endRadius: 430
            )
            .ignoresSafeArea()

            VStack(spacing: 0) {
                banner
                    .padding(.top, 10)
                    .padding(.bottom, 22)
                tabs
                    .padding(.bottom, 18)
                tableActions
                    .padding(.bottom, 12)

                VolumeTable(
                    rows: selected == .watch ? market.watchRows : market.shortlistedRows,
                    allowsRowDelete: selected == .shortlist,
                    onRowDelete: { market.removeShortlisted($0) }
                )
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
            .padding(.horizontal, 14)
            .padding(.bottom, 12)
        }
        .environment(\.layoutDirection, .rightToLeft)
        .onAppear { if scenePhase == .active { market.start() } }
        .onChange(of: scenePhase) { _, phase in
            if phase == .active { market.start() } else { market.pause() }
        }
        .confirmationDialog(
            selected == .watch ? "حذف محتويات جدول المراقبة؟" : "حذف جميع الترشيحات؟",
            isPresented: $showClearConfirmation,
            titleVisibility: .visible
        ) {
            Button("حذف كامل الجدول", role: .destructive) {
                if selected == .watch { market.clearWatch() }
                else { market.clearShortlist() }
            }
            Button("إلغاء", role: .cancel) { }
        }
    }

    private var banner: some View {
        HStack(alignment: .center, spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 16)
                    .fill(ScanTheme.accent.opacity(0.12))
                    .frame(width: 54, height: 54)
                RoundedRectangle(cornerRadius: 16)
                    .strokeBorder(ScanTheme.accent.opacity(0.24), lineWidth: 1)
                    .frame(width: 54, height: 54)
                Image(systemName: "chart.bar.xaxis")
                    .font(.system(size: 24, weight: .medium))
                    .foregroundStyle(ScanTheme.accent)
            }

            VStack(alignment: .leading, spacing: 6) {
                Text("ماسح الفوليوم")
                    .font(.system(size: 23, weight: .bold, design: .rounded))
                    .foregroundStyle(ScanTheme.ink)
                HStack(spacing: 7) {
                    Text("BINANCE SPOT")
                        .font(.system(size: 10, weight: .bold, design: .monospaced))
                        .tracking(1.1)
                    Text("•")
                    Text("USDT")
                        .font(.system(size: 11, weight: .bold, design: .monospaced))
                }
                .foregroundStyle(ScanTheme.muted)
                .environment(\.layoutDirection, .leftToRight)
            }
            Spacer(minLength: 0)
            HStack(spacing: 6) {
                Circle()
                    .fill(market.live ? ScanTheme.accent : ScanTheme.muted)
                    .frame(width: 7, height: 7)
                Text(market.live ? "مباشر" : (market.connecting ? "اتصال" : "تحديث"))
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundStyle(market.live ? ScanTheme.accent : ScanTheme.muted)
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 8)
            .background(Capsule().fill(ScanTheme.panelRaised))
        }
    }

    private var tabs: some View {
        HStack(spacing: 6) {
            tab(.watch, title: "المراقبة", count: market.watchRows.count)
            tab(.shortlist, title: "الترشيحات", count: market.shortlistedRows.count)
        }
        .padding(5)
        .background(RoundedRectangle(cornerRadius: 18).fill(ScanTheme.panel))
        .overlay(RoundedRectangle(cornerRadius: 18).strokeBorder(ScanTheme.line.opacity(0.8), lineWidth: 1))
    }

    private func tab(_ value: ActiveTable, title: String, count: Int) -> some View {
        Button {
            withAnimation(.easeInOut(duration: 0.2)) { selected = value }
        } label: {
            HStack(spacing: 9) {
                Text(title)
                    .font(.system(size: 14, weight: .bold))
                Text("\(count)")
                    .font(.system(size: 11, weight: .bold, design: .monospaced))
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(Capsule().fill(value == selected ? ScanTheme.accent.opacity(0.14) : ScanTheme.panelRaised))
            }
            .foregroundStyle(selected == value ? ScanTheme.accent : ScanTheme.muted)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 11)
            .background(RoundedRectangle(cornerRadius: 14).fill(selected == value ? ScanTheme.panelRaised : .clear))
        }
        .buttonStyle(.plain)
    }

    private var tableActions: some View {
        HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 4) {
                Text(selected == .watch ? "جدول المراقبة" : "جدول الترشيحات")
                    .font(.system(size: 17, weight: .bold))
                    .foregroundStyle(ScanTheme.ink)
                if market.loadedSymbols < market.totalSymbols && market.totalSymbols > 0 {
                    Text("\(market.loadedSymbols) / \(market.totalSymbols)")
                        .font(.system(size: 11, weight: .medium, design: .monospaced))
                        .foregroundStyle(ScanTheme.muted)
                        .environment(\.layoutDirection, .leftToRight)
                }
            }
            Spacer()
            if selected == .watch && market.hiddenCount > 0 {
                Button { market.restoreWatch() } label: {
                    Label("استعادة", systemImage: "arrow.uturn.backward")
                        .font(.system(size: 12, weight: .semibold))
                }
                .foregroundStyle(ScanTheme.accent)
                .buttonStyle(.plain)
            }
            Button { showClearConfirmation = true } label: {
                Label("مسح الكل", systemImage: "trash")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundStyle(ScanTheme.negative)
                    .padding(.vertical, 10)
                    .padding(.horizontal, 11)
                    .background(RoundedRectangle(cornerRadius: 12).fill(ScanTheme.negative.opacity(0.10)))
            }
            .buttonStyle(.plain)
            .disabled(selected == .watch ? market.watchRows.isEmpty : market.shortlistedRows.isEmpty)
            .opacity((selected == .watch ? market.watchRows.isEmpty : market.shortlistedRows.isEmpty) ? 0.45 : 1)
        }
        .padding(.horizontal, 3)
    }
}

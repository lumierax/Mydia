import SwiftUI

private enum TableNumbers {
    static let formatter: NumberFormatter = {
        let fmt = NumberFormatter()
        fmt.locale = Locale(identifier: "en_US")
        fmt.numberStyle = .decimal
        fmt.minimumFractionDigits = 0
        fmt.maximumFractionDigits = 2
        fmt.usesGroupingSeparator = true
        return fmt
    }()

    static func volume(_ value: Double?) -> String {
        guard let value, value.isFinite else { return "—" }
        return formatter.string(from: NSNumber(value: value)) ?? "—"
    }

    static func change(_ value: Double?) -> String {
        guard let value, value.isFinite else { return "—" }
        if abs(value) < 0.005 { return "0" }
        return (value > 0 ? "+" : "−") + volume(abs(value))
    }
}

struct VolumeTable: View {
    let rows: [MarketRow]
    let allowsRowDelete: Bool
    let onRowDelete: (String) -> Void

    private let coinWidth: CGFloat = 133
    private let volumeWidth: CGFloat = 147
    private let differenceWidth: CGFloat = 154
    private let headerHeight: CGFloat = 56
    private let rowHeight: CGFloat = 56

    private var fullWidth: CGFloat { coinWidth + volumeWidth + differenceWidth * 3 }

    var body: some View {
        GeometryReader { geometry in
            ScrollView(.horizontal, showsIndicators: true) {
                VStack(spacing: 0) {
                    headings
                        .frame(height: headerHeight)

                    Rectangle()
                        .fill(ScanTheme.line)
                        .frame(height: 1)

                    ScrollView(.vertical, showsIndicators: true) {
                        LazyVStack(spacing: 0) {
                            ForEach(Array(rows.enumerated()), id: \.element.symbol) { index, row in
                                entry(row, index: index)
                                    .frame(height: rowHeight)
                                Rectangle()
                                    .fill(ScanTheme.line.opacity(0.35))
                                    .frame(height: 1)
                            }
                            if rows.isEmpty {
                                VStack(spacing: 13) {
                                    Image(systemName: "line.3.horizontal.decrease.circle")
                                        .font(.system(size: 31, weight: .ultraLight))
                                    Text("لا توجد عملات")
                                        .font(.system(size: 14, weight: .medium))
                                }
                                .foregroundStyle(ScanTheme.muted)
                                .frame(maxWidth: .infinity)
                                .frame(height: 230)
                            }
                        }
                    }
                    .frame(height: max(90, geometry.size.height - headerHeight - 1))
                }
                .frame(width: fullWidth)
            }
            .background(ScanTheme.panel)
            .clipShape(RoundedRectangle(cornerRadius: 20))
            .overlay(
                RoundedRectangle(cornerRadius: 20)
                    .strokeBorder(ScanTheme.line, lineWidth: 1)
            )
        }
    }

    private var headings: some View {
        HStack(spacing: 0) {
            heading("العملة", width: coinWidth, alignment: .leading)
            heading("حجم 24س المباشر", width: volumeWidth, alignment: .trailing)
            heading("فرق 1س USDT", width: differenceWidth, alignment: .trailing)
            heading("فرق 4س USDT", width: differenceWidth, alignment: .trailing)
            heading("فرق 12س USDT", width: differenceWidth, alignment: .trailing)
        }
        .padding(.horizontal, 0)
        .background(ScanTheme.panelRaised)
    }

    private func heading(_ label: String, width: CGFloat, alignment: Alignment) -> some View {
        Text(label)
            .font(.system(size: 11, weight: .semibold))
            .foregroundStyle(ScanTheme.muted)
            .lineLimit(1)
            .minimumScaleFactor(0.85)
            .frame(width: width - 22, alignment: alignment)
            .padding(.horizontal, 11)
    }

    private func entry(_ row: MarketRow, index: Int) -> some View {
        HStack(spacing: 0) {
            HStack(spacing: 8) {
                if allowsRowDelete {
                    Button { onRowDelete(row.symbol) } label: {
                        Image(systemName: "xmark")
                            .font(.system(size: 10, weight: .heavy))
                            .foregroundStyle(ScanTheme.negative)
                            .frame(width: 25, height: 25)
                            .background(Circle().fill(ScanTheme.negative.opacity(0.11)))
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("حذف \(row.coin) من الترشيحات")
                }
                VStack(alignment: .leading, spacing: 3) {
                    Text(row.coin)
                        .font(.system(size: 13, weight: .bold, design: .rounded))
                        .foregroundStyle(ScanTheme.ink)
                        .lineLimit(1)
                        .minimumScaleFactor(0.8)
                    Text("USDT")
                        .font(.system(size: 9, weight: .medium, design: .monospaced))
                        .foregroundStyle(ScanTheme.muted)
                }
                Spacer(minLength: 0)
            }
            .frame(width: coinWidth - 20)
            .padding(.horizontal, 10)

            numeric(TableNumbers.volume(row.direct24h), width: volumeWidth, color: ScanTheme.ink)
            delta(row.differences.oneHour, width: differenceWidth)
            delta(row.differences.fourHours, width: differenceWidth)
            delta(row.differences.twelveHours, width: differenceWidth)
        }
        .background(index.isMultiple(of: 2) ? ScanTheme.panel : ScanTheme.panelRaised.opacity(0.30))
    }

    private func numeric(_ string: String, width: CGFloat, color: Color) -> some View {
        Text(string)
            .font(.system(size: 12, weight: .semibold, design: .monospaced))
            .monospacedDigit()
            .foregroundStyle(color)
            .lineLimit(1)
            .minimumScaleFactor(0.72)
            .frame(width: width - 20, alignment: .trailing)
            .padding(.horizontal, 10)
            .environment(\.layoutDirection, .leftToRight)
    }

    private func delta(_ value: Double?, width: CGFloat) -> some View {
        let color: Color
        if let value, value > 0.004 { color = ScanTheme.accent }
        else if let value, value < -0.004 { color = ScanTheme.negative }
        else { color = ScanTheme.muted }
        return numeric(TableNumbers.change(value), width: width, color: color)
    }
}

import Foundation
import SwiftUI

@MainActor
final class MarketStore: ObservableObject {
    @Published private(set) var watchRows: [MarketRow] = []
    @Published private(set) var shortlistedRows: [MarketRow] = []
    @Published private(set) var totalSymbols = 0
    @Published private(set) var loadedSymbols = 0
    @Published private(set) var live = false
    @Published private(set) var connecting = true
    @Published private(set) var hiddenCount = 0

    private let engine = MarketEngine()
    private var currentSymbols: [ExchangeSymbol] = []
    private var allRowsBySymbol: [String: MarketRow] = [:]
    private var socketWorkers: [BinanceSocket] = []
    private var socketTasks: [Task<Void, Never>] = []
    private var bootTask: Task<Void, Never>?
    private var historyTask: Task<Void, Never>?
    private var renderTask: Task<Void, Never>?
    private var maintenanceTask: Task<Void, Never>?

    // Keep the shortlist after app relaunch; never remove a candidate because its volume falls.
    private var shortlist: [String] = UserDefaults.standard.stringArray(forKey: "shortlist.v1") ?? []
    private var suppressed: Set<String> = Set(UserDefaults.standard.stringArray(forKey: "suppressed.v1") ?? [])

    // Clearing the first table hides its current entries, but does not stop their scanning.
    // Hidden rows can be restored manually; reopening the app restores the first table too.
    private var hiddenWatch = Set<String>()

    func start() {
        guard bootTask == nil else { return }
        connecting = true
        bootTask = Task { [weak self] in await self?.bootstrap() }
    }

    func pause() {
        bootTask?.cancel()
        historyTask?.cancel()
        renderTask?.cancel()
        maintenanceTask?.cancel()
        bootTask = nil
        historyTask = nil
        renderTask = nil
        maintenanceTask = nil
        for worker in socketWorkers {
            Task { await worker.stop() }
        }
        for task in socketTasks { task.cancel() }
        socketWorkers.removeAll()
        socketTasks.removeAll()
        live = false
        connecting = true
    }

    func clearWatch() {
        hiddenWatch.formUnion(watchRows.map(\.symbol))
        publishRows()
    }

    func restoreWatch() {
        hiddenWatch.removeAll()
        publishRows()
    }

    func removeShortlisted(_ symbol: String) {
        guard shortlist.contains(symbol) else { return }
        shortlist.removeAll { $0 == symbol }
        // Don't instantly promote the same coin again while its old threshold is still met.
        suppressed.insert(symbol)
        hiddenWatch.remove(symbol) // explicitly returns it to the monitored table
        persistSelections()
        publishRows()
    }

    func clearShortlist() {
        for symbol in shortlist {
            suppressed.insert(symbol)
            hiddenWatch.remove(symbol)
        }
        shortlist.removeAll()
        persistSelections()
        publishRows()
    }

    private func bootstrap() async {
        while !Task.isCancelled {
            do {
                let symbols = try await BinanceREST.symbols()
                try Task.checkCancellation()
                currentSymbols = symbols
                totalSymbols = symbols.count
                await engine.setUniverse(symbols)
                if let snapshot = try? await BinanceREST.fullTickerSnapshot() {
                    await engine.setInitialQuotes(snapshot)
                }
                try Task.checkCancellation()
                await receiveSnapshot()
                setupStreams(symbols)
                connecting = false

                // Most-traded coins become fully comparable first.
                let quotes = allRowsBySymbol
                let prioritized = symbols.sorted {
                    (quotes[$0.symbol]?.direct24h ?? 0) > (quotes[$1.symbol]?.direct24h ?? 0)
                }
                historyTask = Task { [weak self] in
                    await self?.hydrate(prioritized.map(\.symbol))
                }
                renderTask = Task { [weak self] in await self?.renderLoop() }
                maintenanceTask = Task { [weak self] in await self?.maintenanceLoop() }
                return
            } catch {
                connecting = true
                try? await Task.sleep(nanoseconds: 8_000_000_000)
            }
        }
    }

    private func setupStreams(_ symbols: [ExchangeSymbol]) {
        for worker in socketWorkers { Task { await worker.stop() } }
        for task in socketTasks { task.cancel() }
        socketWorkers.removeAll()
        socketTasks.removeAll()

        let tickerWorker = BinanceSocket(streams: ["!miniTicker@arr"])
        launch(tickerWorker, repair: [])

        // The websocket limit is 1024 subscribed streams per connection; use 450
        // per connection and create as many connections as needed, with no coin cap.
        let shardSize = 450
        for offset in stride(from: 0, to: symbols.count, by: shardSize) {
            let end = min(offset + shardSize, symbols.count)
            let list = symbols[offset..<end].map { "\($0.symbol.lowercased())@kline_5m" }
            launch(BinanceSocket(streams: list), repair: symbols[offset..<end].map(\.symbol))
        }
    }

    private func launch(_ socket: BinanceSocket, repair symbols: [String]) {
        socketWorkers.append(socket)
        let engine = self.engine
        socketTasks.append(Task { [weak self] in
            await socket.run(
                onMessage: { data in await engine.ingestSocket(data) },
                onReconnect: { [weak self] in
                    guard !symbols.isEmpty else { return }
                    await self?.hydrate(symbols)
                }
            )
        })
    }

    private func hydrate(_ symbols: [String]) async {
        let batchSize = 7
        for start in stride(from: 0, to: symbols.count, by: batchSize) {
            if Task.isCancelled { return }
            let batch = Array(symbols[start..<min(start + batchSize, symbols.count)])
            let engine = self.engine
            await withTaskGroup(of: Void.self) { group in
                for symbol in batch {
                    group.addTask {
                        for attempt in 0..<3 {
                            if Task.isCancelled { return }
                            do {
                                let bars = try await BinanceREST.klines(for: symbol)
                                await engine.loadHistory(for: symbol, bars: bars)
                                return
                            } catch MarketError.rateLimited(let seconds) {
                                try? await Task.sleep(nanoseconds: UInt64(seconds * 1_000_000_000))
                            } catch {
                                let delay = UInt64(attempt + 1) * 900_000_000
                                try? await Task.sleep(nanoseconds: delay)
                            }
                        }
                    }
                }
            }
            // Stagger batches to avoid bursts and respect Binance per-IP weights.
            try? await Task.sleep(nanoseconds: 180_000_000)
        }
    }

    private func renderLoop() async {
        while !Task.isCancelled {
            await receiveSnapshot()
            try? await Task.sleep(nanoseconds: 1_000_000_000)
        }
    }

    private func receiveSnapshot() async {
        let snapshot = await engine.snapshot()
        guard !Task.isCancelled else { return }
        totalSymbols = snapshot.rows.count
        loadedSymbols = snapshot.historyCount
        live = snapshot.lastTickerTime.map { Date().timeIntervalSince($0) < 12 } ?? false
        allRowsBySymbol = Dictionary(uniqueKeysWithValues: snapshot.rows.map { ($0.symbol, $0) })

        var shortlistSet = Set(shortlist)
        var changed = false
        for row in snapshot.rows {
            let metrics = row.differences
            let hasComparison = metrics.oneHour != nil || metrics.fourHours != nil || metrics.twelveHours != nil
            if suppressed.contains(row.symbol) && hasComparison && !metrics.qualifies {
                suppressed.remove(row.symbol)
                changed = true
            }
            if metrics.qualifies && !shortlistSet.contains(row.symbol) && !suppressed.contains(row.symbol) {
                shortlist.append(row.symbol)
                shortlistSet.insert(row.symbol)
                hiddenWatch.remove(row.symbol)
                changed = true
            }
        }
        if changed { persistSelections() }
        publishRows()
    }

    private func publishRows() {
        let shortlistSet = Set(shortlist)
        shortlistedRows = shortlist.reversed().compactMap { allRowsBySymbol[$0] }
        watchRows = allRowsBySymbol.values
            .filter { !shortlistSet.contains($0.symbol) && !hiddenWatch.contains($0.symbol) }
            .sorted {
                let left = $0.differences.oneHour ?? -.infinity
                let right = $1.differences.oneHour ?? -.infinity
                if left != right { return left > right }
                return $0.symbol < $1.symbol
            }
        hiddenCount = hiddenWatch.count
    }

    private func persistSelections() {
        UserDefaults.standard.set(shortlist, forKey: "shortlist.v1")
        UserDefaults.standard.set(Array(suppressed), forKey: "suppressed.v1")
    }

    private func maintenanceLoop() async {
        var count = 0
        while !Task.isCancelled {
            try? await Task.sleep(nanoseconds: 600_000_000_000) // 10 min
            if Task.isCancelled { return }
            count += 1
            do {
                let latest = try await BinanceREST.symbols()
                let oldSymbols = Set(currentSymbols.map(\.symbol))
                let newSymbols = Set(latest.map(\.symbol))
                if oldSymbols != newSymbols {
                    currentSymbols = latest
                    await engine.setUniverse(latest)
                    if let quotes = try? await BinanceREST.fullTickerSnapshot() {
                        await engine.setInitialQuotes(quotes)
                    }
                    setupStreams(latest)
                    let additions = latest.map(\.symbol).filter { !oldSymbols.contains($0) }
                    if !additions.isEmpty { await hydrate(additions) }
                }
            } catch { /* Resume on the next automatic refresh. */ }

            // Re-fetch to repair candle gaps after a Wi-Fi/cellular interruption.
            if count % 3 == 0 {
                await hydrate(currentSymbols.map(\.symbol))
            }
        }
    }
}

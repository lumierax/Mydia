import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

/// A WebSocket connection that reconnects automatically. One connection is used
/// for all-market mini-tickers; kline streams are sharded to stay below 1024.
actor BinanceSocket {
    private let streams: [String]
    private var stopped = false
    private var active: URLSessionWebSocketTask?

    init(streams: [String]) { self.streams = streams }

    func stop() {
        stopped = true
        active?.cancel(with: .goingAway, reason: nil)
    }

    func run(
        onMessage: @escaping @Sendable (Data) async -> Void,
        onReconnect: @escaping @Sendable () async -> Void = {}
    ) async {
        stopped = false
        var failures = 0
        var wasConnected = false

        while !stopped && !Task.isCancelled {
            guard let url = URL(string: "wss://data-stream.binance.vision:443/ws") else { return }
            let socket = URLSession.shared.webSocketTask(with: url)
            active = socket
            socket.resume()

            do {
                // Limit outgoing SUBSCRIBE requests to under 5 messages/second.
                let batchSize = 100
                for offset in stride(from: 0, to: streams.count, by: batchSize) {
                    try Task.checkCancellation()
                    let end = min(offset + batchSize, streams.count)
                    let subscription: [String: Any] = [
                        "method": "SUBSCRIBE",
                        "params": Array(streams[offset..<end]),
                        "id": offset / batchSize + 1
                    ]
                    let bytes = try JSONSerialization.data(withJSONObject: subscription)
                    guard let command = String(data: bytes, encoding: .utf8) else { continue }
                    try await socket.send(.string(command))
                    try await Task.sleep(nanoseconds: 350_000_000)
                }

                if wasConnected {
                    // Repair any five-minute bars missed during the disconnection,
                    // without blocking the live WebSocket receive loop.
                    Task { await onReconnect() }
                }
                wasConnected = true
                failures = 0
                while !stopped && !Task.isCancelled {
                    let message = try await socket.receive()
                    switch message {
                    case .data(let bytes): await onMessage(bytes)
                    case .string(let text):
                        if let bytes = text.data(using: .utf8) { await onMessage(bytes) }
                    @unknown default: break
                    }
                }
            } catch {
                failures += 1
            }

            socket.cancel(with: .goingAway, reason: nil)
            active = nil
            if !stopped && !Task.isCancelled {
                let backoff = min(30, max(2, 1 << min(failures, 5)))
                try? await Task.sleep(nanoseconds: UInt64(backoff) * 1_000_000_000)
            }
        }
    }
}

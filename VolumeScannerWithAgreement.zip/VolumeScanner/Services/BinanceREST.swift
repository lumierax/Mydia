import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

/// Public market-data-only host: no Binance API key and no user-account access.
enum BinanceREST {
    static let host = "https://data-api.binance.vision"

    private static func get(_ path: String, query: [URLQueryItem] = []) async throws -> Data {
        guard var components = URLComponents(string: host + path) else {
            throw MarketError.invalidResponse
        }
        if !query.isEmpty { components.queryItems = query }
        guard let url = components.url else { throw MarketError.invalidResponse }

        var request = URLRequest(url: url)
        request.timeoutInterval = 20
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw MarketError.invalidResponse }
        if http.statusCode == 429 || http.statusCode == 418 {
            let retry = Double(http.value(forHTTPHeaderField: "Retry-After") ?? "") ?? 15
            throw MarketError.rateLimited(max(3, retry))
        }
        guard (200..<300).contains(http.statusCode) else { throw MarketError.http(http.statusCode) }
        return data
    }

    static func symbols() async throws -> [ExchangeSymbol] {
        let data = try await get("/api/v3/exchangeInfo")
        return try JSONDecoder().decode(ExchangeResponse.self, from: data)
            .symbols.filter(\.eligible).sorted { $0.symbol < $1.symbol }
    }

    static func fullTickerSnapshot() async throws -> [String: Double] {
        let data = try await get("/api/v3/ticker/24hr", query: [URLQueryItem(name: "type", value: "MINI")])
        let tickers = try JSONDecoder().decode([TwentyFourHourTicker].self, from: data)
        var result = [String: Double](minimumCapacity: tickers.count)
        for ticker in tickers {
            if let amount = Double(ticker.quoteVolume) { result[ticker.symbol] = amount }
        }
        return result
    }

    static func klines(for symbol: String) async throws -> [FiveMinuteBar] {
        let data = try await get("/api/v3/klines", query: [
            URLQueryItem(name: "symbol", value: symbol),
            URLQueryItem(name: "interval", value: "5m"),
            URLQueryItem(name: "limit", value: "291")
        ])
        guard let matrix = try JSONSerialization.jsonObject(with: data) as? [[Any]] else {
            throw MarketError.invalidResponse
        }
        return matrix.compactMap { row in
            guard row.count >= 8,
                  let open = row[0] as? NSNumber,
                  let quote = row[7] as? String,
                  let value = Double(quote) else { return nil }
            return FiveMinuteBar(openTime: open.int64Value, quoteVolume: value)
        }
    }
}

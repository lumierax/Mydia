import Foundation

/// Keeps high-frequency stream parsing and rolling-window calculations off the UI actor.
actor MarketEngine {
    private var coins: [String: String] = [:]
    private var quotes: [String: Double] = [:]
    private var history: [String: [Int64: Double]] = [:]
    private var loadedHistory = Set<String>()
    private var lastTickerTime: Date?

    func setUniverse(_ symbols: [ExchangeSymbol]) {
        let mapping = Dictionary(uniqueKeysWithValues: symbols.map { ($0.symbol, $0.baseAsset) })
        let allowed = Set(mapping.keys)
        coins = mapping
        quotes = quotes.filter { allowed.contains($0.key) }
        history = history.filter { allowed.contains($0.key) }
        loadedHistory.formIntersection(allowed)
    }

    func setInitialQuotes(_ latest: [String: Double]) {
        // Called before the stream is started (or restarted): overwrite stale
        // cached values with the latest official 24h REST snapshot.
        for (symbol, value) in latest where coins[symbol] != nil {
            quotes[symbol] = value
        }
    }

    func loadHistory(for symbol: String, bars: [FiveMinuteBar]) {
        guard coins[symbol] != nil else { return }
        var current = history[symbol] ?? [:]
        let now = Int64(Date().timeIntervalSince1970 * 1_000)
        let cutoff = VolumeMath.currentOpen(milliseconds: now) - (290 * VolumeMath.fiveMinutes)
        for bar in bars where bar.openTime >= cutoff {
            // Quote volume inside one candle is cumulative, so don't overwrite a
            // newer WebSocket partial-candle update with an older REST response.
            current[bar.openTime] = max(current[bar.openTime] ?? 0, bar.quoteVolume)
        }
        history[symbol] = current.filter { $0.key >= cutoff }
        loadedHistory.insert(symbol)
    }

    func ingestSocket(_ data: Data) {
        guard let obj = try? JSONSerialization.jsonObject(with: data) else { return }

        // !miniTicker@arr: rolling 24h quote volume from Binance, NOT candle-derived.
        if let tickers = obj as? [[String: Any]] {
            var gotTicker = false
            for ticker in tickers {
                guard let symbol = ticker["s"] as? String,
                      coins[symbol] != nil,
                      let amount = ticker["q"] as? String,
                      let quote = Double(amount) else { continue }
                quotes[symbol] = quote
                gotTicker = true
            }
            if gotTicker { lastTickerTime = Date() }
            return
        }

        guard let event = obj as? [String: Any],
              event["e"] as? String == "kline",
              let symbol = event["s"] as? String,
              coins[symbol] != nil,
              let kline = event["k"] as? [String: Any],
              kline["i"] as? String == "5m",
              let openTime = kline["t"] as? NSNumber,
              let quoteString = kline["q"] as? String,
              let quote = Double(quoteString) else { return }

        let open = openTime.int64Value
        var bars = history[symbol] ?? [:]
        bars[open] = max(bars[open] ?? 0, quote)
        // Prune roughly once per candle rather than on each 2-second event.
        if bars.count > 300 {
            let cutoff = open - Int64(290) * VolumeMath.fiveMinutes
            bars = bars.filter { $0.key >= cutoff }
        }
        history[symbol] = bars
    }

    func snapshot() -> MarketSnapshot {
        let clock = Int64(Date().timeIntervalSince1970 * 1_000)
        let anchor = VolumeMath.currentOpen(milliseconds: clock)
        let rows = coins.map { symbol, coin -> MarketRow in
            MarketRow(
                symbol: symbol,
                coin: coin,
                direct24h: quotes[symbol],
                differences: VolumeMath.differences(history[symbol] ?? [:], anchorOpen: anchor)
            )
        }
        return MarketSnapshot(
            rows: rows,
            lastTickerTime: lastTickerTime,
            historyCount: loadedHistory.count
        )
    }
}

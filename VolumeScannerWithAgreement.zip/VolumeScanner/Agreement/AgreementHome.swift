import SwiftUI

private enum AgreementNumber {
    static let formatter: NumberFormatter = {
        let formatter = NumberFormatter()
        formatter.locale = Locale(identifier: "en_US")
        formatter.numberStyle = .decimal
        formatter.minimumFractionDigits = 0
        formatter.maximumFractionDigits = 2
        formatter.usesGroupingSeparator = true
        return formatter
    }()

    static func plain(_ value: Double?) -> String {
        guard let value, value.isFinite else { return "—" }
        return formatter.string(from: NSNumber(value: value)) ?? "—"
    }

    static func signed(_ value: Double?) -> String {
        guard let value, value.isFinite else { return "—" }
        if abs(value) < 0.005 { return "0" }
        return (value > 0 ? "+" : "−") + plain(abs(value))
    }

    static func changeColor(_ value: Double?) -> Color {
        guard let value else { return ScanTheme.muted }
        return value > 0.004 ? ScanTheme.accent : value < -0.004 ? ScanTheme.negative : ScanTheme.muted
    }
}

private enum AgreementDate {
    static let formatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = TimeZone(secondsFromGMT: 0)
        formatter.dateFormat = "MM/dd HH:mm 'UTC'"
        return formatter
    }()

    static func label(_ time: Int64) -> String {
        formatter.string(from: Date(timeIntervalSince1970: Double(time) / 1000))
    }
}

/// A read-only, auto-updating intersection of the volume shortlist and saved breakout hits.
/// The views subscribe to both existing ObservableObjects: deleting from either source
/// immediately removes the corresponding row from this page.
struct AgreementHome: View {
    @EnvironmentObject private var market: MarketStore
    @EnvironmentObject private var breakouts: BreakoutStore
    @State private var activeChart: ChartSelection?

    private var agreements: [AgreementMatch] {
        AgreementMath.matches(shortlist: market.shortlistedRows, breakouts: breakouts.hits)
    }

    var body: some View {
        ZStack {
            ScanTheme.background.ignoresSafeArea()
            RadialGradient(
                colors: [ScanTheme.accent.opacity(0.11), .clear],
                center: .topTrailing,
                startRadius: 20,
                endRadius: 480
            )
            .ignoresSafeArea()

            VStack(alignment: .leading, spacing: 13) {
                titleBar
                summaryBar
                if agreements.isEmpty {
                    emptyState
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    ScrollView(.vertical, showsIndicators: true) {
                        LazyVStack(spacing: 11) {
                            ForEach(agreements) { agreement in
                                AgreementCard(agreement: agreement) { hit in
                                    activeChart = ChartSelection(
                                        symbol: hit.symbol,
                                        timeframe: hit.timeframe,
                                        sourceHit: hit
                                    )
                                }
                            }
                        }
                        .padding(.bottom, 22)
                    }
                }
            }
            .padding(.horizontal, 14)
            .padding(.top, 12)
        }
        .environment(\.layoutDirection, .rightToLeft)
        .sheet(item: $activeChart) { selection in
            BreakoutChartSheet(selection: selection)
                .presentationDetents([.large])
                .presentationDragIndicator(.visible)
        }
    }

    private var titleBar: some View {
        HStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 16)
                    .fill(ScanTheme.accent.opacity(0.12))
                    .frame(width: 50, height: 50)
                Image(systemName: "checkmark.seal.fill")
                    .font(.system(size: 24, weight: .semibold))
                    .foregroundStyle(ScanTheme.accent)
            }
            VStack(alignment: .leading, spacing: 4) {
                Text("التوافق")
                    .font(.system(size: 23, weight: .bold, design: .rounded))
                    .foregroundStyle(ScanTheme.ink)
                Text("VOLUME  ×  BREAKOUTS")
                    .font(.system(size: 10, weight: .bold, design: .monospaced))
                    .tracking(0.6)
                    .foregroundStyle(ScanTheme.muted)
                    .environment(\.layoutDirection, .leftToRight)
            }
            Spacer(minLength: 0)
            Text("\(agreements.count)")
                .font(.system(size: 17, weight: .bold, design: .monospaced))
                .foregroundStyle(ScanTheme.accent)
                .padding(.horizontal, 13)
                .padding(.vertical, 9)
                .background(Capsule().fill(ScanTheme.panelRaised))
        }
    }

    private var summaryBar: some View {
        HStack(spacing: 5) {
            Image(systemName: "chart.bar.fill")
                .foregroundStyle(ScanTheme.accent)
            Text("الترشيحات \(market.shortlistedRows.count)")
            Spacer(minLength: 8)
            Image(systemName: "arrow.up.right.circle.fill")
                .foregroundStyle(ScanTheme.accent)
            Text("الاختراقات \(breakouts.hits.count)")
        }
        .font(.system(size: 11, weight: .semibold))
        .foregroundStyle(ScanTheme.muted)
        .padding(.horizontal, 14)
        .padding(.vertical, 13)
        .background(RoundedRectangle(cornerRadius: 13).fill(ScanTheme.panel))
        .overlay(RoundedRectangle(cornerRadius: 13).strokeBorder(ScanTheme.line, lineWidth: 1))
    }

    private var emptyState: some View {
        VStack(spacing: 12) {
            Image(systemName: "rectangle.on.rectangle.slash")
                .font(.system(size: 36, weight: .ultraLight))
                .foregroundStyle(ScanTheme.muted)
            Text("لا توجد عملات متوافقة حاليًا")
                .font(.system(size: 15, weight: .bold))
                .foregroundStyle(ScanTheme.ink)
            Text("تظهر العملة عند وجودها في الترشيحات والاختراقات معًا")
                .font(.system(size: 11))
                .foregroundStyle(ScanTheme.muted)
                .multilineTextAlignment(.center)
        }
        .padding(25)
        .frame(maxWidth: .infinity)
        .background(RoundedRectangle(cornerRadius: 18).fill(ScanTheme.panel))
        .overlay(RoundedRectangle(cornerRadius: 18).strokeBorder(ScanTheme.line))
    }
}

private struct AgreementCard: View {
    let agreement: AgreementMatch
    let openChart: (BreakoutHit) -> Void

    private let columns = [GridItem(.flexible(), spacing: 8), GridItem(.flexible(), spacing: 8)]

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .center, spacing: 10) {
                Button { openChart(agreement.latest) } label: {
                    HStack(spacing: 8) {
                        VStack(alignment: .leading, spacing: 3) {
                            Text(agreement.volume.coin)
                                .font(.system(size: 19, weight: .bold, design: .rounded))
                                .foregroundStyle(ScanTheme.ink)
                            Text(agreement.volume.symbol)
                                .font(.system(size: 10, weight: .medium, design: .monospaced))
                                .foregroundStyle(ScanTheme.muted)
                        }
                        .environment(\.layoutDirection, .leftToRight)
                        Image(systemName: "chart.xyaxis.line")
                            .font(.system(size: 14, weight: .medium))
                            .foregroundStyle(ScanTheme.accent)
                    }
                }
                .buttonStyle(.plain)
                Spacer(minLength: 0)
                VStack(alignment: .trailing, spacing: 5) {
                    HStack(spacing: 5) {
                        Image(systemName: agreement.latest.direction == .up ? "arrow.up.right" : "arrow.down.right")
                        Text(agreement.latest.direction.label)
                    }
                    .font(.system(size: 11, weight: .bold))
                    .foregroundStyle(agreement.latest.direction == .up ? ScanTheme.accent : ScanTheme.negative)
                    Text(AgreementDate.label(agreement.latest.closeTime))
                        .font(.system(size: 10, weight: .medium, design: .monospaced))
                        .foregroundStyle(ScanTheme.muted)
                        .environment(\.layoutDirection, .leftToRight)
                }
            }

            LazyVGrid(columns: columns, spacing: 8) {
                metric("حجم 24س المباشر", AgreementNumber.plain(agreement.volume.direct24h), color: ScanTheme.ink)
                metric("فرق 1س · USDT", AgreementNumber.signed(agreement.volume.differences.oneHour), color: AgreementNumber.changeColor(agreement.volume.differences.oneHour))
                metric("فرق 4س · USDT", AgreementNumber.signed(agreement.volume.differences.fourHours), color: AgreementNumber.changeColor(agreement.volume.differences.fourHours))
                metric("فرق 12س · USDT", AgreementNumber.signed(agreement.volume.differences.twelveHours), color: AgreementNumber.changeColor(agreement.volume.differences.twelveHours))
            }

            HStack(spacing: 8) {
                Text("الفريمات المتوافقة")
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundStyle(ScanTheme.muted)
                Spacer()
                Text("\(agreement.timeframes.count)")
                    .font(.system(size: 11, weight: .semibold, design: .monospaced))
                    .foregroundStyle(ScanTheme.accent)
            }

            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 7) {
                    ForEach(agreement.timeframes) { hit in
                        Button { openChart(hit) } label: {
                            HStack(spacing: 5) {
                                Image(systemName: hit.direction == .up ? "arrow.up.right" : "arrow.down.right")
                                    .font(.system(size: 10, weight: .bold))
                                Text(hit.timeframe.rawValue)
                                    .font(.system(size: 12, weight: .bold, design: .monospaced))
                            }
                            .foregroundStyle(hit.direction == .up ? ScanTheme.accent : ScanTheme.negative)
                            .padding(.horizontal, 12)
                            .padding(.vertical, 8)
                            .background(Capsule().fill((hit.direction == .up ? ScanTheme.accent : ScanTheme.negative).opacity(0.10)))
                            .overlay(Capsule().strokeBorder((hit.direction == .up ? ScanTheme.accent : ScanTheme.negative).opacity(0.20)))
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel("فتح شارت \(hit.symbol) فريم \(hit.timeframe.rawValue)، \(hit.direction.label)")
                    }
                }
                .environment(\.layoutDirection, .leftToRight)
            }
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(RoundedRectangle(cornerRadius: 18).fill(ScanTheme.panel))
        .overlay(RoundedRectangle(cornerRadius: 18).strokeBorder(ScanTheme.line, lineWidth: 1))
    }

    private func metric(_ title: String, _ amount: String, color: Color) -> some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(title)
                .font(.system(size: 10, weight: .medium))
                .foregroundStyle(ScanTheme.muted)
                .lineLimit(1)
                .minimumScaleFactor(0.8)
            Text(amount)
                .font(.system(size: 13, weight: .bold, design: .monospaced))
                .monospacedDigit()
                .foregroundStyle(color)
                .lineLimit(1)
                .minimumScaleFactor(0.70)
                .environment(\.layoutDirection, .leftToRight)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(10)
        .background(RoundedRectangle(cornerRadius: 11).fill(ScanTheme.panelRaised))
    }
}

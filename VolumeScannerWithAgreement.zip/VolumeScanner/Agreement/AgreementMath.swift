import Foundation

/// A coin appears in this tab only while it is present in BOTH source tables.
/// One latest saved breakout per timeframe is retained for a compact UI.
/// No extra scan, network request, or separate cache is used here.
struct AgreementMatch: Identifiable, Sendable {
    let volume: MarketRow
    let timeframes: [BreakoutHit]
    let latest: BreakoutHit

    var id: String { volume.symbol }
}

enum AgreementMath {
    static func matches(shortlist: [MarketRow], breakouts: [BreakoutHit]) -> [AgreementMatch] {
        var hitsByCoin: [String: [BreakoutTimeframe: BreakoutHit]] = [:]

        for hit in breakouts {
            if let previous = hitsByCoin[hit.symbol]?[hit.timeframe], !newer(hit, than: previous) {
                continue
            }
            hitsByCoin[hit.symbol, default: [:]][hit.timeframe] = hit
        }

        var result: [AgreementMatch] = []
        result.reserveCapacity(min(shortlist.count, hitsByCoin.count))
        for row in shortlist {
            guard let perFrame = hitsByCoin[row.symbol], !perFrame.isEmpty else { continue }
            let signals = perFrame.values.sorted { $0.timeframe.order < $1.timeframe.order }
            guard let latest = signals.max(by: { newer($1, than: $0) }) else { continue }
            result.append(AgreementMatch(volume: row, timeframes: signals, latest: latest))
        }
        return result.sorted {
            if $0.latest.closeTime != $1.latest.closeTime {
                return $0.latest.closeTime > $1.latest.closeTime
            }
            return $0.volume.symbol < $1.volume.symbol
        }
    }

    private static func newer(_ a: BreakoutHit, than b: BreakoutHit) -> Bool {
        if a.closeTime != b.closeTime { return a.closeTime > b.closeTime }
        if a.barTime != b.barTime { return a.barTime > b.barTime }
        return a.direction.rawValue > b.direction.rawValue
    }
}

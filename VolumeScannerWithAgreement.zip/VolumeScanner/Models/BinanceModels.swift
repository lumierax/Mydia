import Foundation

struct ExchangeResponse: Decodable {
    let symbols: [ExchangeSymbol]
}

struct ExchangeSymbol: Decodable, Sendable {
    let symbol: String
    let baseAsset: String
    let quoteAsset: String
    let status: String
    let isSpotTradingAllowed: Bool?
    let permissions: [String]?

    var eligible: Bool {
        guard status == "TRADING", quoteAsset == "USDT" else { return false }
        // Binance may omit the legacy flag; /exchangeInfo otherwise includes SPOT pairs.
        if isSpotTradingAllowed == false { return false }
        if let permissions, !permissions.isEmpty, !permissions.contains("SPOT") {
            return false
        }
        return true
    }
}

struct TwentyFourHourTicker: Decodable {
    let symbol: String
    let quoteVolume: String
}

struct FiveMinuteBar: Sendable {
    let openTime: Int64
    let quoteVolume: Double
}

enum MarketError: LocalizedError {
    case invalidResponse
    case http(Int)
    case rateLimited(Double)

    var errorDescription: String? {
        switch self {
        case .invalidResponse: return "تعذّر قراءة بيانات بينانس"
        case .http(let code): return "HTTP \(code)"
        case .rateLimited: return "تم بلوغ حد طلبات بينانس"
        }
    }
}

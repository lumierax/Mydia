import Foundation

/// Every bar represents the quote-asset volume (USDT) of one UTC five-minute interval.
/// Differences compare two consecutive and equally sized sets of CLOSED bars.
struct VolumeDifferences: Sendable {
    let oneHour: Double?
    let fourHours: Double?
    let twelveHours: Double?

    var qualifies: Bool {
        (oneHour ?? -.infinity) >= 250_000 ||
        (fourHours ?? -.infinity) >= 1_000_000 ||
        (twelveHours ?? -.infinity) >= 3_000_000
    }
}

enum VolumeMath {
    static let fiveMinutes: Int64 = 300_000
    static let barsInDay = 288

    static func currentOpen(milliseconds: Int64) -> Int64 {
        (milliseconds / fiveMinutes) * fiveMinutes
    }

    /// Returns nil for a particular comparison if ANY required five-minute bar is missing.
    /// This prevents presenting misleading numbers for newly listed coins and data gaps.
    static func differences(_ bars: [Int64: Double], anchorOpen: Int64) -> VolumeDifferences {
        var prefix = [Double](repeating: 0, count: barsInDay + 1)
        var missing = [Int](repeating: 0, count: barsInDay + 1)

        for index in 0..<barsInDay {
            let time = anchorOpen - Int64(barsInDay - index) * fiveMinutes
            let value = bars[time]
            prefix[index + 1] = prefix[index] + (value ?? 0)
            missing[index + 1] = missing[index] + (value == nil ? 1 : 0)
        }

        func difference(barsPerWindow n: Int) -> Double? {
            let start = barsInDay - (2 * n)
            guard missing[barsInDay] == missing[start] else { return nil }
            let recent = prefix[barsInDay] - prefix[barsInDay - n]
            let previous = prefix[barsInDay - n] - prefix[start]
            let delta = recent - previous
            return abs(delta) < 0.00000001 ? 0 : delta
        }

        return VolumeDifferences(
            oneHour: difference(barsPerWindow: 12),
            fourHours: difference(barsPerWindow: 48),
            twelveHours: difference(barsPerWindow: 144)
        )
    }
}

struct MarketRow: Identifiable, Sendable {
    let symbol: String
    let coin: String
    let direct24h: Double?
    let differences: VolumeDifferences

    var id: String { symbol }
}

struct MarketSnapshot: Sendable {
    let rows: [MarketRow]
    let lastTickerTime: Date?
    let historyCount: Int
}

import Foundation

/// Literal Swift port of the supplied LuxAlgo-style breakout scanner.
/// Pivot length 24, ATR/RMA slope multiplier 1.4; only CLOSED bars can create hits.
enum BreakoutMath {
    static let length = 24
    static let multiplier = 1.4

    private static func pivot(_ candles: [BreakoutCandle], at index: Int, high: Bool) -> Double? {
        guard index >= 2 * length else { return nil }
        let center = index - length
        let value = high ? candles[center].high : candles[center].low
        for j in (center - length)...index where j != center {
            let other = high ? candles[j].high : candles[j].low
            if high ? (other > value || (j > center && other == value))
                    : (other < value || (j > center && other == value)) { return nil }
        }
        return value
    }

    /// Wilder's RMA (SMA seeded), matching the user's JavaScript rma().
    static func rma(_ values: [Double], period: Int) -> [Double] {
        guard period > 0 else { return Array(repeating: .nan, count: values.count) }
        var result = [Double](repeating: .nan, count: values.count)
        var sum = 0.0
        var previous = Double.nan
        for index in values.indices {
            if index < period {
                sum += values[index]
                if index == period - 1 {
                    previous = sum / Double(period)
                    result[index] = previous
                }
            } else {
                previous = (previous * Double(period - 1) + values[index]) / Double(period)
                result[index] = previous
            }
        }
        return result
    }

    static func trendlines(_ candles: [BreakoutCandle]) -> [TrendlinePoint] {
        guard !candles.isEmpty else { return [] }
        let trueRanges = candles.indices.map { i -> Double in
            let candle = candles[i]
            if i == 0 { return candle.high - candle.low }
            let lastClose = candles[i - 1].close
            return max(candle.high - candle.low, abs(candle.high - lastClose), abs(candle.low - lastClose))
        }
        let atr = rma(trueRanges, period: length)
        var upper = 0.0, lower = 0.0, highSlope = 0.0, lowSlope = 0.0
        var upPosition = 0, downPosition = 0
        var highAnchor: BreakoutAnchor?, lowAnchor: BreakoutAnchor?
        var result: [TrendlinePoint] = []
        result.reserveCapacity(candles.count)

        for i in candles.indices {
            let candle = candles[i]
            let ph = pivot(candles, at: i, high: true)
            let pl = pivot(candles, at: i, high: false)
            let slope = atr[i] / Double(length) * multiplier
            let previousUp = upPosition, previousDown = downPosition

            if let ph {
                highSlope = slope
                highAnchor = BreakoutAnchor(index: i - length, confirmedIndex: i, value: ph, slope: slope)
            }
            if let pl {
                lowSlope = slope
                lowAnchor = BreakoutAnchor(index: i - length, confirmedIndex: i, value: pl, slope: slope)
            }
            upper = ph ?? upper - highSlope
            lower = pl ?? lower + lowSlope
            let highLevel = upper - highSlope * Double(length)
            let lowLevel = lower + lowSlope * Double(length)

            upPosition = ph != nil ? 0 : (candle.close > highLevel ? 1 : upPosition)
            downPosition = pl != nil ? 0 : (candle.close < lowLevel ? 1 : downPosition)
            result.append(TrendlinePoint(
                upper: highAnchor == nil ? nil : upper,
                lower: lowAnchor == nil ? nil : lower,
                upperSignal: highAnchor == nil ? nil : highLevel,
                lowerSignal: lowAnchor == nil ? nil : lowLevel,
                resetUpper: ph != nil,
                resetLower: pl != nil,
                highAnchor: highAnchor,
                lowAnchor: lowAnchor,
                upBreak: i > 0 && highAnchor != nil && upPosition > previousUp,
                downBreak: i > 0 && lowAnchor != nil && downPosition > previousDown
            ))
        }
        return result
    }

    static func hits(
        _ closedCandles: [BreakoutCandle],
        symbol: String,
        timeframe: BreakoutTimeframe,
        lastClosedWindow: Int
    ) -> [BreakoutHit] {
        guard closedCandles.count >= 2 * length + 2 else { return [] }
        let trend = trendlines(closedCandles)
        let start = max(0, trend.count - max(1, min(lastClosedWindow, 50)))
        var hits: [BreakoutHit] = []
        for index in start..<trend.count {
            let point = trend[index]
            let candle = closedCandles[index]
            let age = trend.count - 1 - index
            if point.upBreak, let level = point.upperSignal {
                hits.append(BreakoutHit(
                    symbol: symbol, timeframe: timeframe, direction: .up,
                    barTime: candle.openTime, closeTime: candle.closeTime,
                    price: candle.close, level: level, age: age
                ))
            }
            if point.downBreak, let level = point.lowerSignal {
                hits.append(BreakoutHit(
                    symbol: symbol, timeframe: timeframe, direction: .down,
                    barTime: candle.openTime, closeTime: candle.closeTime,
                    price: candle.close, level: level, age: age
                ))
            }
        }
        return hits
    }

    static func ema(_ values: [Double], length: Int) -> [Double] {
        guard !values.isEmpty && length > 0 else { return [] }
        let alpha = 2 / Double(length + 1)
        var previous = values[0]
        var results = [previous]
        results.reserveCapacity(values.count)
        for value in values.dropFirst() {
            previous = alpha * value + (1 - alpha) * previous
            results.append(previous)
        }
        return results
    }

    static func indicators(_ candles: [BreakoutCandle]) -> BreakoutChartIndicators {
        let closes = candles.map(\.close)
        let fast = ema(closes, length: 12), slow = ema(closes, length: 26)
        let macd = zip(fast, slow).map(-)
        let signal = ema(macd, length: 9)
        return BreakoutChartIndicators(
            ema50: ema(closes, length: 50),
            ema100: ema(closes, length: 100),
            ema200: ema(closes, length: 200),
            macd: macd,
            signal: signal,
            histogram: zip(macd, signal).map(-)
        )
    }
}

import SwiftUI

private enum PlotPalette {
    static let background = Color(red: 0.036, green: 0.061, blue: 0.095)
    static let grid = Color(red: 0.13, green: 0.19, blue: 0.25)
    static let text = Color(red: 0.59, green: 0.68, blue: 0.79)
    static let up = Color(red: 0.20, green: 0.76, blue: 0.58)
    static let down = Color(red: 0.94, green: 0.36, blue: 0.37)
    static let upper = Color(red: 0.02, green: 0.62, blue: 0.55)
    static let lower = Color(red: 1.0, green: 0.32, blue: 0.34)
    static let ema50 = Color(red: 0.90, green: 0.72, blue: 0.27)
    static let ema100 = Color(red: 0.70, green: 0.58, blue: 0.97)
    static let ema200 = Color(red: 0.39, green: 0.71, blue: 0.96)
}

/// Fully native candlestick chart. Displays the same 24/1.4/ATR trendline
/// algorithm used by the scanner, three EMAs and a MACD(12,26,9) pane.
struct BreakoutChartPlot: View {
    let candles: [BreakoutCandle]
    let selectedBreakout: BreakoutHit?
    @State private var visibleBarCount = 72
    @State private var previousBars = 0
    @State private var inspectedIndex: Int?

    var body: some View {
        VStack(spacing: 10) {
            HStack(spacing: 10) {
                Button {
                    previousBars = min(max(0, candles.count - visibleBarCount), previousBars + 30)
                } label: {
                    Image(systemName: "chevron.backward")
                }
                .accessibilityLabel("شموع أقدم")
                .disabled(candles.count <= visibleBarCount || previousBars >= candles.count - visibleBarCount)
                Spacer()
                Button {
                    visibleBarCount = max(35, visibleBarCount - 20)
                    previousBars = 0
                } label: {
                    Image(systemName: "plus.magnifyingglass")
                }
                .accessibilityLabel("تكبير الشارت")
                Text("\(visibleBarCount) شمعة")
                    .font(.system(size: 10, weight: .medium, design: .monospaced))
                    .foregroundStyle(ScanTheme.muted)
                Button {
                    visibleBarCount = min(170, visibleBarCount + 20)
                    previousBars = 0
                } label: {
                    Image(systemName: "minus.magnifyingglass")
                }
                .accessibilityLabel("تصغير الشارت")
                Spacer()
                Button { previousBars = max(0, previousBars - 30) } label: {
                    Image(systemName: "chevron.forward")
                }
                .accessibilityLabel("شموع أحدث")
                .disabled(previousBars == 0)
                Button { previousBars = 0 } label: {
                    Image(systemName: "arrow.right.to.line")
                }
                .accessibilityLabel("العودة لآخر شمعة")
                .disabled(previousBars == 0)
            }
            .font(.system(size: 15, weight: .semibold))
            .foregroundStyle(ScanTheme.accent)
            .buttonStyle(.plain)
            .padding(.horizontal, 11)

            GeometryReader { proxy in
                Canvas(opaque: true) { context, size in
                    draw(context: context, size: size)
                }
                .contentShape(Rectangle())
                .gesture(
                    DragGesture(minimumDistance: 0)
                        .onChanged { value in
                            guard !candles.isEmpty else { return }
                            let count = min(visibleBarCount, candles.count)
                            let end = max(0, candles.count - 1 - previousBars)
                            let first = max(0, end - count + 1)
                            let width = max(1, proxy.size.width - 92)
                            let fraction = min(1, max(0, (value.location.x - 9) / width))
                            inspectedIndex = first + Int(fraction * CGFloat(max(0, end - first)))
                        }
                        .onEnded { _ in inspectedIndex = nil }
                )
            }
            .frame(height: 460)
            .clipShape(RoundedRectangle(cornerRadius: 12))
            .overlay(RoundedRectangle(cornerRadius: 12).strokeBorder(ScanTheme.line, lineWidth: 1))

            if let inspectedIndex, candles.indices.contains(inspectedIndex) {
                let candle = candles[inspectedIndex]
                HStack(spacing: 9) {
                    Text("O \(Self.price(candle.open))")
                    Text("H \(Self.price(candle.high))")
                    Text("L \(Self.price(candle.low))")
                    Text("C \(Self.price(candle.close))")
                }
                .font(.system(size: 10, weight: .medium, design: .monospaced))
                .foregroundStyle(ScanTheme.ink)
                .frame(maxWidth: .infinity)
                .environment(\.layoutDirection, .leftToRight)
            }
        }
    }

    static func price(_ v: Double) -> String {
        guard v.isFinite else { return "—" }
        if v >= 100 { return String(format: "%.2f", v) }
        if v >= 1 { return String(format: "%.4f", v) }
        if v >= 0.01 { return String(format: "%.6f", v) }
        return String(format: "%.8f", v)
    }

    private func draw(context: GraphicsContext, size: CGSize) {
        context.fill(Path(CGRect(origin: .zero, size: size)), with: .color(PlotPalette.background))
        guard candles.count >= 2 else { return }

        let visible = min(visibleBarCount, candles.count)
        let end = max(0, candles.count - 1 - previousBars)
        let start = max(0, end - visible + 1)
        guard end > start else { return }
        let indicators = BreakoutMath.indicators(candles)
        let trend = BreakoutMath.trendlines(candles)

        let left: CGFloat = 8
        let right: CGFloat = max(left + 30, size.width - 75)
        let top: CGFloat = 30
        let priceBottom: CGFloat = 302
        let macdTop: CGFloat = 348
        let macdBottom: CGFloat = 426
        let spacing = (right - left) / CGFloat(end - start + 1)
        func x(_ index: Int) -> CGFloat { left + CGFloat(index - start + 0) * spacing + spacing / 2 }

        var minimum = Double.infinity, maximum = -Double.infinity
        for i in start...end {
            minimum = min(minimum, candles[i].low)
            maximum = max(maximum, candles[i].high)
            minimum = min(minimum, indicators.ema50[i], indicators.ema100[i], indicators.ema200[i])
            maximum = max(maximum, indicators.ema50[i], indicators.ema100[i], indicators.ema200[i])
        }
        guard minimum.isFinite && maximum.isFinite else { return }
        let margin = max((maximum - minimum) * 0.09, maximum * 0.0007)
        minimum -= margin
        maximum += margin
        let priceRange = max(maximum - minimum, 1e-15)
        func y(_ value: Double) -> CGFloat {
            priceBottom - CGFloat((value - minimum) / priceRange) * (priceBottom - top)
        }
        func point(_ index: Int, _ value: Double) -> CGPoint { CGPoint(x: x(index), y: y(value)) }
        func line(_ from: CGPoint, _ to: CGPoint, _ color: Color, width: CGFloat = 1, dash: [CGFloat] = []) {
            var path = Path()
            path.move(to: from)
            path.addLine(to: to)
            context.stroke(path, with: .color(color), style: StrokeStyle(lineWidth: width, dash: dash))
        }
        func text(_ content: String, at location: CGPoint, color: Color = PlotPalette.text, anchor: UnitPoint = .leading) {
            context.draw(
                Text(content).font(.system(size: 9, weight: .medium, design: .monospaced)).foregroundColor(color),
                at: location, anchor: anchor
            )
        }

        for tick in 0...4 {
            let price = minimum + Double(tick) * priceRange / 4
            let level = y(price)
            line(CGPoint(x: left, y: level), CGPoint(x: right, y: level), PlotPalette.grid)
            text(Self.price(price), at: CGPoint(x: right + 7, y: level), anchor: .leading)
        }
        text("BINANCE SPOT", at: CGPoint(x: left + 4, y: 15))

        var priceContext = context
        priceContext.clip(to: Path(CGRect(x: left, y: top, width: right - left, height: priceBottom - top)))
        for i in start...end {
            let candle = candles[i]
            let isUp = candle.close >= candle.open
            let color = isUp ? PlotPalette.up : PlotPalette.down
            let center = x(i)
            let bodyWidth = max(1, min(spacing * 0.68, 10))
            var wick = Path()
            wick.move(to: CGPoint(x: center, y: y(candle.high)))
            wick.addLine(to: CGPoint(x: center, y: y(candle.low)))
            priceContext.stroke(wick, with: .color(color), lineWidth: 1)
            let bodyTop = min(y(candle.open), y(candle.close))
            let bodyHeight = max(1.1, abs(y(candle.close) - y(candle.open)))
            priceContext.fill(
                Path(CGRect(x: center - bodyWidth / 2, y: bodyTop, width: bodyWidth, height: bodyHeight)),
                with: .color(color)
            )
        }

        func drawSeries(_ series: [Double], _ color: Color, width: CGFloat = 1.3) {
            var path = Path()
            for i in start...end {
                let value = series[i]
                if i == start { path.move(to: point(i, value)) }
                else { path.addLine(to: point(i, value)) }
            }
            priceContext.stroke(path, with: .color(color), lineWidth: width)
        }
        drawSeries(indicators.ema50, PlotPalette.ema50)
        drawSeries(indicators.ema100, PlotPalette.ema100)
        drawSeries(indicators.ema200, PlotPalette.ema200)

        // In the supplied script backpaint=true: the pivot line is displayed 24 bars back.
        for upper in [true, false] {
            let color = upper ? PlotPalette.upper : PlotPalette.lower
            var path = Path(), connected = false
            for i in trend.indices {
                let plottedIndex = i - BreakoutMath.length
                if plottedIndex < start || plottedIndex > end { continue }
                let item = trend[i]
                let value = upper ? item.upper : item.lower
                let hasAnchor = upper ? item.highAnchor != nil : item.lowAnchor != nil
                let reset = upper ? item.resetUpper : item.resetLower
                guard let value, value.isFinite, hasAnchor, !reset else {
                    connected = false
                    continue
                }
                let destination = point(plottedIndex, value)
                if connected { path.addLine(to: destination) }
                else { path.move(to: destination) }
                connected = true
            }
            priceContext.stroke(path, with: .color(color), lineWidth: 1.65)

            // Last confirmed pivot projected forward (the dashed LuxAlgo extension).
            if let last = trend.last,
               let anchor = upper ? last.highAnchor : last.lowAnchor {
                let from = max(start, anchor.index)
                if from <= end {
                    let slope = (upper ? -1.0 : 1.0) * anchor.slope
                    let firstValue = anchor.value + slope * Double(from - anchor.index)
                    let endValue = anchor.value + slope * Double(end - anchor.index)
                    var extensionPath = Path()
                    extensionPath.move(to: point(from, firstValue))
                    extensionPath.addLine(to: point(end, endValue))
                    priceContext.stroke(extensionPath, with: .color(color),
                                        style: StrokeStyle(lineWidth: 1.35, dash: [5, 4]))
                }
            }
        }

        // B markers show confirmed breakouts in historical CLOSED candles only.
        for i in start...end {
            let candle = candles[i]
            let closed = candle.closeTime < Int64(Date().timeIntervalSince1970 * 1_000)
            if !closed { continue }
            let value = trend[i]
            if !value.upBreak && !value.downBreak { continue }
            let upward = value.upBreak
            let isChosen = selectedBreakout?.barTime == candle.openTime &&
                selectedBreakout?.direction == (upward ? .up : .down)
            let markerColor = upward ? PlotPalette.upper : PlotPalette.lower
            let markY = max(top + 10, min(priceBottom - 10,
                                          y(upward ? candle.low : candle.high) + (upward ? 13 : -13)))
            let rectangle = CGRect(x: x(i) - 8, y: markY - 9, width: 16, height: 18)
            context.fill(Path(roundedRect: rectangle, cornerRadius: 4), with: .color(markerColor))
            if isChosen {
                context.stroke(Path(roundedRect: rectangle, cornerRadius: 4),
                               with: .color(PlotPalette.ema50), lineWidth: 2)
            }
            text("B", at: CGPoint(x: x(i), y: markY), color: .white, anchor: .center)
        }

        // Interaction crosshair.
        if let index = inspectedIndex, (start...end).contains(index) {
            let p = point(index, candles[index].close)
            line(CGPoint(x: p.x, y: top), CGPoint(x: p.x, y: macdBottom), PlotPalette.text,
                 width: 0.7, dash: [3, 3])
            context.fill(Path(ellipseIn: CGRect(x: p.x - 3, y: p.y - 3, width: 6, height: 6)),
                         with: .color(PlotPalette.ema50))
        }

        let formatter = DateFormatter()
        formatter.timeZone = TimeZone(secondsFromGMT: 0)
        formatter.dateFormat = "MM/dd HH:mm"
        for i in Set([start, (start + end) / 2, end]).sorted() {
            let stamp = formatter.string(from: Date(timeIntervalSince1970: Double(candles[i].openTime) / 1000))
            text(stamp, at: CGPoint(x: x(i), y: 320), anchor: i == start ? .leading : (i == end ? .trailing : .center))
        }

        text("MACD 12 · 26 · 9", at: CGPoint(x: left + 4, y: 337))
        var macdMinimum = 0.0, macdMaximum = 0.0
        for i in start...end {
            for value in [indicators.macd[i], indicators.signal[i], indicators.histogram[i]] {
                macdMinimum = min(macdMinimum, value)
                macdMaximum = max(macdMaximum, value)
            }
        }
        let extra = max((macdMaximum - macdMinimum) * 0.12, 1e-12)
        macdMinimum -= extra
        macdMaximum += extra
        let macdRange = max(macdMaximum - macdMinimum, 1e-15)
        func macdY(_ value: Double) -> CGFloat {
            macdBottom - CGFloat((value - macdMinimum) / macdRange) * (macdBottom - macdTop)
        }
        line(CGPoint(x: left, y: macdY(0)), CGPoint(x: right, y: macdY(0)), PlotPalette.grid)
        for i in start...end {
            let histogram = indicators.histogram[i]
            let center = x(i)
            let width = max(1, spacing * 0.62)
            let topY = min(macdY(0), macdY(histogram))
            let height = max(0.9, abs(macdY(histogram) - macdY(0)))
            let color = histogram >= 0 ? PlotPalette.up : PlotPalette.down
            context.fill(Path(CGRect(x: center - width / 2, y: topY, width: width, height: height)),
                         with: .color(color.opacity(0.86)))
        }
        func macdLine(_ series: [Double], _ color: Color) {
            var path = Path()
            for i in start...end {
                let destination = CGPoint(x: x(i), y: macdY(series[i]))
                if i == start { path.move(to: destination) }
                else { path.addLine(to: destination) }
            }
            context.stroke(path, with: .color(color), lineWidth: 1.25)
        }
        macdLine(indicators.macd, PlotPalette.ema200)
        macdLine(indicators.signal, PlotPalette.ema50)
        text(Self.price(macdMaximum), at: CGPoint(x: right + 6, y: macdY(macdMaximum)))
        text(Self.price(macdMinimum), at: CGPoint(x: right + 6, y: macdY(macdMinimum)))
    }
}

import Foundation
import SwiftUI

private struct BreakoutScanItem: Sendable {
    let results: [BreakoutHit]
    let failed: Bool
    let insufficient: Bool
    let limited: Bool
}

/// Every trading Spot/USDT pair is scanned; no top-N universe or symbol cap.
@MainActor
final class BreakoutStore: ObservableObject {
    @Published private(set) var hits: [BreakoutHit] = []
    @Published private(set) var scanning = false
    @Published private(set) var autoEnabled = UserDefaults.standard.bool(forKey: "breakouts.auto.v1")
    @Published private(set) var scannedPairs = 0
    @Published private(set) var totalPairs = 0
    @Published private(set) var currentFrame = ""
    @Published private(set) var message = "جاهز للفحص"
    @Published private(set) var lastScan: Date?
    @Published var lookback: Int = max(1, min(UserDefaults.standard.integer(forKey: "breakouts.window.v1"), 50)) {
        didSet {
            lookback = max(1, min(lookback, 50))
            UserDefaults.standard.set(lookback, forKey: "breakouts.window.v1")
        }
    }

    private var scanTask: Task<Void, Never>?
    private var autoTask: Task<Void, Never>?
    private var cachedSymbols: [String] = []
    private var symbolsAt = Date.distantPast
    private var lastClosed: [String: Int64] = UserDefaults.standard.dictionary(forKey: "breakouts.closed.v1") as? [String: Int64] ?? [:]
    private let storedHitsKey = "breakouts.results.v1"

    init() {
        if let data = UserDefaults.standard.data(forKey: storedHitsKey),
           let stored = try? JSONDecoder().decode([BreakoutHit].self, from: data) {
            hits = stored
        }
    }

    func beginScanAll() {
        guard !scanning && scanTask == nil else { return }
        scanTask = Task { [weak self] in
            guard let self else { return }
            await self.runScan(frames: BreakoutTimeframe.allCases)
            self.scanTask = nil
        }
    }

    func cancelCurrentScan() {
        if let scanTask {
            scanTask.cancel()
            self.scanTask = nil
        } else if scanning {
            // The running scan belongs to the hourly automation.
            stopAuto()
        }
        message = "تم طلب إيقاف الفحص"
    }

    func clearResults() {
        cancelCurrentScan()
        stopAuto()
        hits.removeAll()
        UserDefaults.standard.removeObject(forKey: storedHitsKey)
        scannedPairs = 0
        totalPairs = 0
        currentFrame = ""
        message = "تم مسح جدول الاختراقات"
    }

    func startAuto() {
        guard !autoEnabled else { return }
        autoEnabled = true
        UserDefaults.standard.set(true, forKey: "breakouts.auto.v1")
        resumeAuto()
    }

    func stopAuto() {
        autoEnabled = false
        UserDefaults.standard.set(false, forKey: "breakouts.auto.v1")
        autoTask?.cancel()
        autoTask = nil
        if !scanning { message = "الفحص التلقائي متوقف" }
    }

    func resumeAuto() {
        guard autoEnabled && autoTask == nil else { return }
        autoTask = Task { [weak self] in await self?.autoLoop() }
    }

    func pause() {
        scanTask?.cancel()
        scanTask = nil
        autoTask?.cancel()
        autoTask = nil
        // The iOS system suspends WebSockets and networking in the background.
    }

    private func universe() async throws -> [String] {
        if !cachedSymbols.isEmpty && Date().timeIntervalSince(symbolsAt) < 3600 {
            return cachedSymbols
        }
        let marketSymbols = try await BinanceREST.symbols().map(\.symbol)
        guard !marketSymbols.isEmpty else { throw MarketError.invalidResponse }
        cachedSymbols = marketSymbols
        symbolsAt = Date()
        return marketSymbols
    }

    /// A completed frame's hits are persisted, not removed in later scans.
    /// Existing historical signals only disappear when the user clears the table.
    private func merge(_ additions: [BreakoutHit]) {
        var byID = Dictionary(uniqueKeysWithValues: hits.map { ($0.id, $0) })
        for hit in additions { byID[hit.id] = hit }
        hits = byID.values.sorted {
            if $0.timeframe.order != $1.timeframe.order { return $0.timeframe.order < $1.timeframe.order }
            if $0.closeTime != $1.closeTime { return $0.closeTime > $1.closeTime }
            return $0.symbol < $1.symbol
        }
        persist()
    }

    private func persist() {
        if let data = try? JSONEncoder().encode(hits) {
            UserDefaults.standard.set(data, forKey: storedHitsKey)
        }
    }

    @discardableResult
    private func runScan(frames: [BreakoutTimeframe]) async -> Bool {
        guard !scanning else { return false }
        scanning = true
        scannedPairs = 0
        currentFrame = ""
        message = "جاري جلب أزواج Binance Spot / USDT"
        defer { scanning = false; currentFrame = "" }

        do {
            let symbols = try await universe()
            try Task.checkCancellation()
            let now = (try? await BreakoutAPI.shared.serverMilliseconds())
                ?? Int64(Date().timeIntervalSince1970 * 1000)
            totalPairs = symbols.count * frames.count
            let selectedLookback = lookback
            var errors = 0, skipped = 0

            for frame in frames {
                try Task.checkCancellation()
                currentFrame = frame.rawValue
                var additions: [BreakoutHit] = []
                for offset in stride(from: 0, to: symbols.count, by: 4) {
                    try Task.checkCancellation()
                    let batch = Array(symbols[offset..<min(offset + 4, symbols.count)])
                    let output = await withTaskGroup(of: BreakoutScanItem.self, returning: [BreakoutScanItem].self) { group in
                        for symbol in batch {
                            group.addTask {
                                do {
                                    let bars = try await BreakoutAPI.shared.candles(
                                        symbol: symbol, timeframe: frame, limit: 500, endTime: now - 1
                                    )
                                    let closed = bars.filter { $0.closeTime < now }
                                    if closed.count < BreakoutMath.length * 2 + 2 {
                                        return BreakoutScanItem(results: [], failed: false, insufficient: true, limited: false)
                                    }
                                    let hits = BreakoutMath.hits(
                                        closed, symbol: symbol, timeframe: frame,
                                        lastClosedWindow: selectedLookback
                                    )
                                    return BreakoutScanItem(results: hits, failed: false, insufficient: false, limited: false)
                                } catch is CancellationError {
                                    return BreakoutScanItem(results: [], failed: true, insufficient: false, limited: false)
                                } catch MarketError.rateLimited {
                                    return BreakoutScanItem(results: [], failed: true, insufficient: false, limited: true)
                                } catch {
                                    return BreakoutScanItem(results: [], failed: true, insufficient: false, limited: false)
                                }
                            }
                        }
                        var responses: [BreakoutScanItem] = []
                        for await response in group { responses.append(response) }
                        return responses
                    }
                    try Task.checkCancellation()
                    for item in output {
                        additions.append(contentsOf: item.results)
                        if item.failed { errors += 1 }
                        if item.insufficient { skipped += 1 }
                    }
                    scannedPairs += batch.count
                    message = "\(frame.rawValue) · \(scannedPairs)/\(totalPairs) · اختراقات \(additions.count) · أخطاء \(errors)"
                    if output.contains(where: \.limited) {
                        throw MarketError.rateLimited(60)
                    }
                }
                try Task.checkCancellation()
                merge(additions)
                if let checked = try? await BreakoutAPI.shared.lastClosedTime(timeframe: frame, at: now) {
                    lastClosed[frame.rawValue] = checked
                    UserDefaults.standard.set(lastClosed, forKey: "breakouts.closed.v1")
                }
            }
            lastScan = Date()
            message = "اكتمل الفحص · \(scannedPairs) زوج/فريم · \(hits.count) اختراق · بيانات ناقصة \(skipped) · أخطاء \(errors)"
            return true
        } catch is CancellationError {
            message = "تم إيقاف الفحص"
            return false
        } catch {
            message = "تعذّر إكمال الفحص: \(error.localizedDescription)"
            return false
        }
    }

    private func autoLoop() async {
        defer { autoTask = nil }
        if lastClosed.isEmpty {
            await syncAutoBaseline()
        }
        while autoEnabled && !Task.isCancelled {
            let milliseconds = Int64(Date().timeIntervalSince1970 * 1000)
            let hour: Int64 = 3_600_000
            let latestCheck = (milliseconds / hour) * hour + 20_000
            let target = latestCheck > milliseconds ? latestCheck : latestCheck + hour
            do { try await Task.sleep(nanoseconds: UInt64(target - milliseconds) * 1_000_000) }
            catch { return }
            if Task.isCancelled || !autoEnabled { return }
            await hourlyCheck()
        }
    }

    private func syncAutoBaseline() async {
        let now = (try? await BreakoutAPI.shared.serverMilliseconds())
            ?? Int64(Date().timeIntervalSince1970 * 1000)
        for tf in BreakoutTimeframe.allCases {
            if Task.isCancelled { return }
            if let closed = try? await BreakoutAPI.shared.lastClosedTime(timeframe: tf, at: now) {
                lastClosed[tf.rawValue] = closed
            }
        }
        UserDefaults.standard.set(lastClosed, forKey: "breakouts.closed.v1")
        if !scanning { message = "التلقائي يعمل · الفحص عند إغلاق شمعة جديدة" }
    }

    private func hourlyCheck() async {
        guard !scanning else { return }
        let now = (try? await BreakoutAPI.shared.serverMilliseconds())
            ?? Int64(Date().timeIntervalSince1970 * 1000)
        var due: [BreakoutTimeframe] = []
        for tf in BreakoutTimeframe.allCases {
            if Task.isCancelled { return }
            guard let observed = try? await BreakoutAPI.shared.lastClosedTime(timeframe: tf, at: now) else { continue }
            if let old = lastClosed[tf.rawValue] {
                if observed > old { due.append(tf) }
            } else {
                lastClosed[tf.rawValue] = observed
            }
        }
        UserDefaults.standard.set(lastClosed, forKey: "breakouts.closed.v1")
        if !due.isEmpty { _ = await runScan(frames: due) }
        else if !scanning { message = "لا توجد شموع مغلقة جديدة في الفريمات السبعة" }
    }
}

import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

/// Deliberately throttled because the volume scanner is also using the public API.
private actor BreakoutRequestPacer {
    private var nextSlot = Date.distantPast
    func waitForSlot() async throws {
        let now = Date()
        let slot = max(now, nextSlot)
        nextSlot = slot.addingTimeInterval(0.085)
        let delay = slot.timeIntervalSince(now)
        if delay > 0 {
            try await Task.sleep(nanoseconds: UInt64(delay * 1_000_000_000))
        }
    }
}

actor BreakoutAPI {
    static let shared = BreakoutAPI()
    private let base = "https://data-api.binance.vision"
    private let pacer = BreakoutRequestPacer()

    private func request(_ path: String, query: [URLQueryItem] = []) async throws -> Data {
        guard var components = URLComponents(string: base + path) else { throw MarketError.invalidResponse }
        if !query.isEmpty { components.queryItems = query }
        guard let url = components.url else { throw MarketError.invalidResponse }

        for attempt in 0..<4 {
            try Task.checkCancellation()
            try await pacer.waitForSlot()
            var request = URLRequest(url: url)
            request.timeoutInterval = 20
            request.setValue("application/json", forHTTPHeaderField: "Accept")
            do {
                let (data, response) = try await URLSession.shared.data(for: request)
                guard let http = response as? HTTPURLResponse else { throw MarketError.invalidResponse }
                if http.statusCode == 418 || http.statusCode == 429 {
                    let retrySeconds = Double(http.value(forHTTPHeaderField: "Retry-After") ?? "") ?? 12
                    if attempt == 3 { throw MarketError.rateLimited(retrySeconds) }
                    try await Task.sleep(nanoseconds: UInt64(max(5, min(retrySeconds, 120)) * 1_000_000_000))
                    continue
                }
                if (500...599).contains(http.statusCode) && attempt < 3 {
                    try await Task.sleep(nanoseconds: UInt64(2 << attempt) * 1_000_000_000)
                    continue
                }
                guard (200...299).contains(http.statusCode) else { throw MarketError.http(http.statusCode) }
                return data
            } catch is CancellationError {
                throw CancellationError()
            } catch {
                if attempt == 3 || (error as? MarketError) != nil { throw error }
                try await Task.sleep(nanoseconds: UInt64(1 << attempt) * 1_000_000_000)
            }
        }
        throw MarketError.invalidResponse
    }

    func serverMilliseconds() async throws -> Int64 {
        let data = try await request("/api/v3/time")
        guard let object = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              let serverTime = object["serverTime"] as? NSNumber else {
            throw MarketError.invalidResponse
        }
        return serverTime.int64Value
    }

    func candles(
        symbol: String,
        timeframe: BreakoutTimeframe,
        limit: Int = 500,
        endTime: Int64? = nil
    ) async throws -> [BreakoutCandle] {
        var query = [
            URLQueryItem(name: "symbol", value: symbol),
            URLQueryItem(name: "interval", value: timeframe.rawValue),
            URLQueryItem(name: "limit", value: String(max(1, min(limit, 1000))))
        ]
        if let endTime { query.append(URLQueryItem(name: "endTime", value: String(endTime))) }
        let data = try await request("/api/v3/klines", query: query)
        guard let raw = try JSONSerialization.jsonObject(with: data) as? [[Any]] else {
            throw MarketError.invalidResponse
        }
        return raw.compactMap { row in
            guard row.count >= 8,
                  let start = (row[0] as? NSNumber)?.int64Value,
                  let finish = (row[6] as? NSNumber)?.int64Value,
                  let open = Double(row[1] as? String ?? ""),
                  let high = Double(row[2] as? String ?? ""),
                  let low = Double(row[3] as? String ?? ""),
                  let close = Double(row[4] as? String ?? ""),
                  let volume = Double(row[5] as? String ?? ""),
                  let quote = Double(row[7] as? String ?? "") else { return nil }
            let candle = BreakoutCandle(openTime: start, closeTime: finish,
                                         open: open, high: high, low: low, close: close,
                                         volume: volume, quoteVolume: quote)
            return candle.valid ? candle : nil
        }
    }

    func lastClosedTime(timeframe: BreakoutTimeframe, at time: Int64) async throws -> Int64? {
        let candles = try await candles(symbol: "BTCUSDT", timeframe: timeframe, limit: 3, endTime: time - 1)
        return candles.last(where: { $0.closeTime < time })?.closeTime
    }
}

import Foundation

enum BreakoutTimeframe: String, CaseIterable, Codable, Identifiable, Sendable {
    case h4 = "4h"
    case h6 = "6h"
    case h8 = "8h"
    case h12 = "12h"
    case d1 = "1d"
    case d3 = "3d"
    case w1 = "1w"

    var id: String { rawValue }
    var order: Int { Self.allCases.firstIndex(of: self) ?? 0 }
}

struct BreakoutCandle: Sendable {
    let openTime: Int64
    let closeTime: Int64
    let open: Double
    let high: Double
    let low: Double
    let close: Double
    let volume: Double
    let quoteVolume: Double

    var valid: Bool {
        openTime >= 0 && closeTime > openTime &&
        [open, high, low, close, volume, quoteVolume].allSatisfy(\.isFinite) &&
        open > 0 && high > 0 && low > 0 && close > 0 && volume >= 0
    }
}

enum BreakoutDirection: String, Codable, Sendable {
    case up = "UP"
    case down = "DOWN"

    var label: String { self == .up ? "اختراق صاعد" : "كسر هابط" }
}

struct BreakoutHit: Codable, Identifiable, Sendable {
    let symbol: String
    let timeframe: BreakoutTimeframe
    let direction: BreakoutDirection
    let barTime: Int64
    let closeTime: Int64
    let price: Double
    let level: Double
    let age: Int

    var id: String { "\(symbol)|\(timeframe.rawValue)|\(barTime)|\(direction.rawValue)" }
}

struct BreakoutAnchor: Sendable {
    let index: Int
    let confirmedIndex: Int
    let value: Double
    let slope: Double
}

struct TrendlinePoint: Sendable {
    let upper: Double?
    let lower: Double?
    let upperSignal: Double?
    let lowerSignal: Double?
    let resetUpper: Bool
    let resetLower: Bool
    let highAnchor: BreakoutAnchor?
    let lowAnchor: BreakoutAnchor?
    let upBreak: Bool
    let downBreak: Bool
}

struct BreakoutChartIndicators: Sendable {
    let ema50: [Double]
    let ema100: [Double]
    let ema200: [Double]
    let macd: [Double]
    let signal: [Double]
    let histogram: [Double]
}

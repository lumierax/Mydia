import SwiftUI

struct BreakoutChartSheet: View {
    let selection: ChartSelection
    @Environment(\.dismiss) private var dismiss
    @Environment(\.scenePhase) private var scenePhase
    @StateObject private var chart: LiveBreakoutChartStore

    init(selection: ChartSelection) {
        self.selection = selection
        _chart = StateObject(wrappedValue: LiveBreakoutChartStore(
            symbol: selection.symbol, timeframe: selection.timeframe
        ))
    }

    var body: some View {
        ZStack {
            ScanTheme.background.ignoresSafeArea()
            ScrollView(.vertical) {
                VStack(alignment: .leading, spacing: 14) {
                    title
                    timeframes
                    priceSummary

                    if chart.loading && chart.candles.isEmpty {
                        ProgressView("جاري تحميل الشارت")
                            .tint(ScanTheme.accent)
                            .foregroundStyle(ScanTheme.muted)
                            .frame(maxWidth: .infinity)
                            .frame(height: 330)
                    } else if chart.candles.isEmpty {
                        Text(chart.status)
                            .font(.system(size: 13))
                            .foregroundStyle(ScanTheme.negative)
                            .frame(maxWidth: .infinity)
                            .frame(height: 280)
                    } else {
                        BreakoutChartPlot(
                            candles: chart.candles,
                            selectedBreakout: chart.timeframe == selection.timeframe ? selection.sourceHit : nil
                        )
                        .padding(8)
                        .background(RoundedRectangle(cornerRadius: 16).fill(ScanTheme.panel))
                    }
                    legend
                    HStack(spacing: 6) {
                        Circle()
                            .fill(chart.connected ? ScanTheme.accent : ScanTheme.muted)
                            .frame(width: 7, height: 7)
                        Text(chart.status)
                            .font(.system(size: 11, weight: .medium))
                            .foregroundStyle(chart.connected ? ScanTheme.accent : ScanTheme.muted)
                        Spacer()
                        if let last = chart.latestUpdate {
                            Text(last, style: .time)
                                .font(.system(size: 10, design: .monospaced))
                                .foregroundStyle(ScanTheme.muted)
                        }
                    }
                    .padding(.horizontal, 6)
                }
                .padding(.horizontal, 14)
                .padding(.top, 20)
                .padding(.bottom, 24)
            }
        }
        .environment(\.layoutDirection, .rightToLeft)
        .onAppear { chart.start() }
        .onChange(of: scenePhase) { _, phase in
            if phase == .active { chart.start() }
            else { chart.stop() }
        }
        .onDisappear { chart.stop() }
    }

    private var title: some View {
        HStack {
            VStack(alignment: .leading, spacing: 5) {
                Text(selection.symbol)
                    .font(.system(size: 22, weight: .bold, design: .monospaced))
                    .foregroundStyle(ScanTheme.ink)
                    .environment(\.layoutDirection, .leftToRight)
                Text("BINANCE SPOT · \(chart.timeframe.rawValue)")
                    .font(.system(size: 10, weight: .bold, design: .monospaced))
                    .foregroundStyle(ScanTheme.muted)
                    .environment(\.layoutDirection, .leftToRight)
            }
            Spacer()
            Button { chart.refresh() } label: {
                Image(systemName: "arrow.clockwise")
                    .font(.system(size: 15, weight: .semibold))
                    .frame(width: 39, height: 39)
                    .foregroundStyle(ScanTheme.accent)
                    .background(RoundedRectangle(cornerRadius: 12).fill(ScanTheme.panelRaised))
            }
            .accessibilityLabel("تحديث الشارت")
            Button { dismiss() } label: {
                Image(systemName: "xmark")
                    .font(.system(size: 14, weight: .bold))
                    .frame(width: 39, height: 39)
                    .foregroundStyle(ScanTheme.ink)
                    .background(RoundedRectangle(cornerRadius: 12).fill(ScanTheme.panelRaised))
            }
            .accessibilityLabel("إغلاق الشارت")
        }
    }

    private var timeframes: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 6) {
                ForEach(BreakoutTimeframe.allCases) { timeframe in
                    Button { chart.changeTimeframe(timeframe) } label: {
                        Text(timeframe.rawValue)
                            .font(.system(size: 12, weight: .bold, design: .monospaced))
                            .foregroundStyle(chart.timeframe == timeframe ? ScanTheme.background : ScanTheme.ink)
                            .padding(.horizontal, 15)
                            .padding(.vertical, 9)
                            .background(Capsule().fill(chart.timeframe == timeframe ? ScanTheme.accent : ScanTheme.panelRaised))
                    }
                    .buttonStyle(.plain)
                }
            }
            .environment(\.layoutDirection, .leftToRight)
        }
    }

    private var priceSummary: some View {
        HStack(spacing: 9) {
            if let latest = chart.candles.last {
                VStack(alignment: .leading, spacing: 3) {
                    Text("آخر سعر")
                        .font(.system(size: 10))
                        .foregroundStyle(ScanTheme.muted)
                    Text(BreakoutChartPlot.price(latest.close))
                        .font(.system(size: 19, weight: .bold, design: .monospaced))
                        .foregroundStyle(latest.close >= latest.open ? ScanTheme.accent : ScanTheme.negative)
                }
                .environment(\.layoutDirection, .leftToRight)
                Spacer()
                VStack(alignment: .trailing, spacing: 4) {
                    Text("H \(BreakoutChartPlot.price(latest.high))")
                    Text("L \(BreakoutChartPlot.price(latest.low))")
                }
                .font(.system(size: 11, weight: .medium, design: .monospaced))
                .foregroundStyle(ScanTheme.muted)
                .environment(\.layoutDirection, .leftToRight)
            } else {
                Text("—")
                    .foregroundStyle(ScanTheme.muted)
            }
        }
        .padding(13)
        .frame(maxWidth: .infinity)
        .background(RoundedRectangle(cornerRadius: 13).fill(ScanTheme.panel))
    }

    private var legend: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 15) {
                item("ترند علوي", color: Color(red: 0.02, green: 0.62, blue: 0.55))
                item("ترند سفلي", color: ScanTheme.negative)
                item("EMA 50", color: Color(red: 0.90, green: 0.72, blue: 0.27))
            }
            HStack(spacing: 15) {
                item("EMA 100", color: Color(red: 0.70, green: 0.58, blue: 0.97))
                item("EMA 200", color: Color(red: 0.39, green: 0.71, blue: 0.96))
                item("B = اختراق", color: ScanTheme.accent)
            }
            Text("24 / 1.4 / ATR · MACD 12/26/9")
                .font(.system(size: 10, weight: .medium, design: .monospaced))
                .foregroundStyle(ScanTheme.muted)
                .environment(\.layoutDirection, .leftToRight)
        }
        .padding(.horizontal, 6)
    }

    private func item(_ title: String, color: Color) -> some View {
        HStack(spacing: 4) {
            Circle().fill(color).frame(width: 7, height: 7)
            Text(title).font(.system(size: 10, weight: .medium))
                .foregroundStyle(ScanTheme.muted)
        }
    }
}

import SwiftUI

struct ChartSelection: Identifiable {
    let symbol: String
    let timeframe: BreakoutTimeframe
    let sourceHit: BreakoutHit?
    var id: String { "\(symbol):\(timeframe.rawValue)" }
}

private enum BreakoutCellText {
    static func time(_ milliseconds: Int64) -> String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = TimeZone(secondsFromGMT: 0)
        formatter.dateFormat = "MM/dd HH:mm 'UTC'"
        return formatter.string(from: Date(timeIntervalSince1970: Double(milliseconds) / 1000))
    }
}

struct BreakoutsHome: View {
    @EnvironmentObject private var scanner: BreakoutStore
    @Environment(\.scenePhase) private var scenePhase
    @State private var activeChart: ChartSelection?
    @State private var clearConfirmation = false

    var body: some View {
        ZStack {
            ScanTheme.background.ignoresSafeArea()
            RadialGradient(
                colors: [ScanTheme.accent.opacity(0.08), .clear],
                center: .topTrailing, startRadius: 15, endRadius: 430
            )
            .ignoresSafeArea()

            VStack(alignment: .leading, spacing: 12) {
                header
                controlPanel
                resultsHeader
                BreakoutResultsTable(rows: scanner.hits) { row in
                    activeChart = ChartSelection(symbol: row.symbol,
                                                 timeframe: row.timeframe, sourceHit: row)
                }
                .frame(maxHeight: .infinity)
            }
            .padding(.horizontal, 14)
            .padding(.top, 12)
            .padding(.bottom, 9)
        }
        .environment(\.layoutDirection, .rightToLeft)
        .onAppear {
            if scenePhase == .active { scanner.resumeAuto() }
        }
        .onChange(of: scenePhase) { _, phase in
            if phase == .active { scanner.resumeAuto() }
            else { scanner.pause() }
        }
        .sheet(item: $activeChart) { selection in
            BreakoutChartSheet(selection: selection)
                .presentationDragIndicator(.visible)
                .presentationDetents([.large])
        }
        .confirmationDialog("مسح جميع إشارات الاختراقات؟",
                            isPresented: $clearConfirmation, titleVisibility: .visible) {
            Button("حذف جميع الاختراقات", role: .destructive) { scanner.clearResults() }
            Button("إلغاء", role: .cancel) { }
        }
    }

    private var header: some View {
        HStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 16)
                    .fill(ScanTheme.accent.opacity(0.12))
                    .frame(width: 50, height: 50)
                Image(systemName: "arrow.up.right.circle")
                    .font(.system(size: 24, weight: .semibold))
                    .foregroundStyle(ScanTheme.accent)
            }
            VStack(alignment: .leading, spacing: 4) {
                Text("الاختراقات")
                    .font(.system(size: 23, weight: .bold, design: .rounded))
                    .foregroundStyle(ScanTheme.ink)
                Text("BINANCE SPOT  ·  USDT")
                    .font(.system(size: 10, weight: .bold, design: .monospaced))
                    .foregroundStyle(ScanTheme.muted)
                    .environment(\.layoutDirection, .leftToRight)
            }
            Spacer()
            Text("\(scanner.hits.count)")
                .font(.system(size: 16, weight: .bold, design: .monospaced))
                .foregroundStyle(ScanTheme.accent)
                .padding(.horizontal, 12)
                .padding(.vertical, 8)
                .background(Capsule().fill(ScanTheme.panelRaised))
        }
    }

    private var controlPanel: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 9) {
                Text("نافذة الاختراق")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundStyle(ScanTheme.ink)
                Spacer()
                Stepper(value: $scanner.lookback, in: 1...50) {
                    Text("\(scanner.lookback) شمعة مغلقة")
                        .font(.system(size: 11, weight: .medium))
                        .foregroundStyle(ScanTheme.muted)
                }
                .fixedSize()
                .tint(ScanTheme.accent)
            }
            .padding(.horizontal, 2)

            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 6) {
                    ForEach(BreakoutTimeframe.allCases) { tf in
                        Text(tf.rawValue)
                            .font(.system(size: 12, weight: .bold, design: .monospaced))
                            .foregroundStyle(ScanTheme.muted)
                            .padding(.horizontal, 13)
                            .padding(.vertical, 7)
                            .background(Capsule().fill(ScanTheme.panelRaised))
                    }
                }
                .environment(\.layoutDirection, .leftToRight)
            }
            HStack(spacing: 8) {
                Button { scanner.beginScanAll() } label: {
                    Label("فحص كل الفريمات", systemImage: "play.fill")
                        .font(.system(size: 11, weight: .bold))
                        .frame(maxWidth: .infinity)
                        .frame(height: 38)
                        .background(RoundedRectangle(cornerRadius: 10).fill(ScanTheme.accent))
                        .foregroundStyle(ScanTheme.background)
                }
                .disabled(scanner.scanning)
                .opacity(scanner.scanning ? 0.5 : 1)

                Button {
                    if scanner.autoEnabled { scanner.stopAuto() }
                    else { scanner.startAuto() }
                } label: {
                    Label(scanner.autoEnabled ? "إيقاف التلقائي" : "تلقائي كل ساعة",
                          systemImage: scanner.autoEnabled ? "pause.fill" : "clock.arrow.circlepath")
                        .font(.system(size: 11, weight: .semibold))
                        .frame(maxWidth: .infinity)
                        .frame(height: 38)
                        .background(RoundedRectangle(cornerRadius: 10).fill(ScanTheme.panelRaised))
                        .foregroundStyle(ScanTheme.ink)
                }
            }
            .buttonStyle(.plain)

            if scanner.scanning {
                ProgressView(value: Double(scanner.scannedPairs), total: Double(max(1, scanner.totalPairs)))
                    .tint(ScanTheme.accent)
                HStack(spacing: 8) {
                    Text(scanner.message)
                        .font(.system(size: 10, weight: .medium))
                        .foregroundStyle(ScanTheme.muted)
                        .lineLimit(2)
                    Spacer(minLength: 4)
                    Button("إيقاف الفحص") { scanner.cancelCurrentScan() }
                        .font(.system(size: 10, weight: .semibold))
                        .foregroundStyle(ScanTheme.negative)
                }
            } else {
                Text(scanner.message)
                    .font(.system(size: 10, weight: .medium))
                    .foregroundStyle(ScanTheme.muted)
                    .lineLimit(2)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
        .padding(12)
        .background(RoundedRectangle(cornerRadius: 17).fill(ScanTheme.panel))
        .overlay(RoundedRectangle(cornerRadius: 17).strokeBorder(ScanTheme.line))
    }

    private var resultsHeader: some View {
        HStack {
            Text("جدول الاختراقات")
                .font(.system(size: 16, weight: .bold))
                .foregroundStyle(ScanTheme.ink)
            Spacer()
            Button { clearConfirmation = true } label: {
                Label("مسح الكل", systemImage: "trash")
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundStyle(ScanTheme.negative)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 9)
                    .background(RoundedRectangle(cornerRadius: 10)
                        .fill(ScanTheme.negative.opacity(0.10)))
            }
            .disabled(scanner.hits.isEmpty)
            .opacity(scanner.hits.isEmpty ? 0.5 : 1)
        }
        .padding(.horizontal, 3)
    }
}

private struct BreakoutResultsTable: View {
    let rows: [BreakoutHit]
    let onOpenChart: (BreakoutHit) -> Void

    private let widths: [CGFloat] = [122, 64, 128, 132, 128, 142]
    private var tableWidth: CGFloat { widths.reduce(0, +) }

    var body: some View {
        GeometryReader { proxy in
            ScrollView(.horizontal, showsIndicators: true) {
                VStack(spacing: 0) {
                    HStack(spacing: 0) {
                        heading("العملة", width: widths[0])
                        heading("الفريم", width: widths[1])
                        heading("الإشارة", width: widths[2])
                        heading("موقع الشمعة", width: widths[3])
                        heading("سعر الإغلاق", width: widths[4])
                        heading("وقت الإغلاق", width: widths[5])
                    }
                    .frame(height: 45)
                    .background(ScanTheme.panelRaised)

                    ScrollView(.vertical) {
                        LazyVStack(spacing: 0) {
                            if rows.isEmpty {
                                VStack(spacing: 11) {
                                    Image(systemName: "chart.xyaxis.line")
                                        .font(.system(size: 28, weight: .ultraLight))
                                    Text("لا توجد اختراقات محفوظة")
                                        .font(.system(size: 12, weight: .medium))
                                }
                                .foregroundStyle(ScanTheme.muted)
                                .frame(width: tableWidth, height: 230)
                            }
                            ForEach(Array(rows.enumerated()), id: \.element.id) { index, hit in
                                HStack(spacing: 0) {
                                    Button { onOpenChart(hit) } label: {
                                        HStack(spacing: 4) {
                                            Text(hit.symbol.replacingOccurrences(of: "USDT", with: ""))
                                                .font(.system(size: 11, weight: .bold, design: .monospaced))
                                            Image(systemName: "chart.xyaxis.line")
                                                .font(.system(size: 9))
                                        }
                                        .foregroundStyle(ScanTheme.accent)
                                        .frame(width: widths[0], alignment: .center)
                                    }
                                    .buttonStyle(.plain)
                                    cell(hit.timeframe.rawValue, width: widths[1])
                                    Text(hit.direction.label)
                                        .font(.system(size: 11, weight: .bold))
                                        .foregroundStyle(hit.direction == .up ? ScanTheme.accent : ScanTheme.negative)
                                        .frame(width: widths[2])
                                    cell(hit.age == 0 ? "آخر شمعة" : "قبل \(hit.age) شمعة", width: widths[3])
                                    cell(BreakoutChartPlot.price(hit.price), width: widths[4])
                                    cell(BreakoutCellText.time(hit.closeTime), width: widths[5])
                                }
                                .frame(height: 53)
                                .background(index.isMultiple(of: 2) ? ScanTheme.panel : ScanTheme.panelRaised.opacity(0.32))
                                Rectangle().fill(ScanTheme.line.opacity(0.40)).frame(height: 1)
                            }
                        }
                    }
                    .frame(height: max(80, proxy.size.height - 46))
                }
                .frame(width: tableWidth)
            }
            .background(ScanTheme.panel)
            .clipShape(RoundedRectangle(cornerRadius: 16))
            .overlay(RoundedRectangle(cornerRadius: 16).strokeBorder(ScanTheme.line))
        }
    }

    private func heading(_ name: String, width: CGFloat) -> some View {
        Text(name)
            .font(.system(size: 10, weight: .semibold))
            .foregroundStyle(ScanTheme.muted)
            .frame(width: width)
            .lineLimit(1)
    }

    private func cell(_ value: String, width: CGFloat) -> some View {
        Text(value)
            .font(.system(size: 10, weight: .medium, design: .monospaced))
            .foregroundStyle(ScanTheme.ink)
            .lineLimit(1)
            .minimumScaleFactor(0.8)
            .frame(width: width)
            .environment(\.layoutDirection, .leftToRight)
    }
}

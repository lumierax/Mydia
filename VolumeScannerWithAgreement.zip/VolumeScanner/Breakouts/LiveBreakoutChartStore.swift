import Foundation
import SwiftUI

/// A single, currently visible symbol/timeframe stream. The full-universe scanner
/// deliberately uses closed candles and is separate from this live chart.
@MainActor
final class LiveBreakoutChartStore: ObservableObject {
    let symbol: String
    @Published private(set) var timeframe: BreakoutTimeframe
    @Published private(set) var candles: [BreakoutCandle] = []
    @Published private(set) var loading = false
    @Published private(set) var connected = false
    @Published private(set) var latestUpdate: Date?
    @Published private(set) var status = ""

    private var epoch = 0
    private var lastSocketEvent: Date?
    private var loadingTask: Task<Void, Never>?
    private var socketTask: Task<Void, Never>?
    private var recoveryTask: Task<Void, Never>?
    private var socket: BinanceSocket?

    init(symbol: String, timeframe: BreakoutTimeframe) {
        self.symbol = symbol
        self.timeframe = timeframe
    }

    func start() {
        cancelWorkers()
        epoch += 1
        let version = epoch
        loading = true
        connected = false
        lastSocketEvent = nil
        status = "جاري جلب شموع Binance Spot"
        candles = []
        loadingTask = Task { [weak self] in
            guard let self else { return }
            do {
                let bars = try await BreakoutAPI.shared.candles(
                    symbol: self.symbol, timeframe: self.timeframe, limit: 500
                )
                guard !Task.isCancelled && self.epoch == version else { return }
                guard !bars.isEmpty else { throw MarketError.invalidResponse }
                self.candles = bars
                self.loading = false
                self.latestUpdate = Date()
                self.status = "مزامنة البث المباشر"
                self.launchStream(version: version)
                self.launchRecovery(version: version)
            } catch {
                guard self.epoch == version && !Task.isCancelled else { return }
                self.loading = false
                self.status = "تعذّر جلب الشارت: \(error.localizedDescription)"
            }
        }
    }

    func changeTimeframe(_ next: BreakoutTimeframe) {
        guard timeframe != next else { return }
        timeframe = next
        start()
    }

    func refresh() {
        let version = epoch
        Task { [weak self] in await self?.recover(version: version, manual: true) }
    }

    func stop() {
        epoch += 1
        cancelWorkers()
        connected = false
    }

    private func cancelWorkers() {
        loadingTask?.cancel()
        loadingTask = nil
        recoveryTask?.cancel()
        recoveryTask = nil
        socketTask?.cancel()
        socketTask = nil
        if let socket { Task { await socket.stop() } }
        socket = nil
    }

    private func launchStream(version: Int) {
        let streamName = "\(symbol.lowercased())@kline_\(timeframe.rawValue)"
        let connection = BinanceSocket(streams: [streamName])
        socket = connection
        socketTask = Task { [weak self] in
            await connection.run(
                onMessage: { [weak self] data in
                    await self?.receiveSocket(data, version: version)
                },
                onReconnect: { [weak self] in
                    await self?.recover(version: version, manual: false)
                }
            )
        }
    }

    private func launchRecovery(version: Int) {
        recoveryTask = Task { [weak self] in
            while !Task.isCancelled {
                do { try await Task.sleep(nanoseconds: 45_000_000_000) }
                catch { return }
                guard !Task.isCancelled else { return }
                await self?.recover(version: version, manual: false)
            }
        }
    }

    private func recover(version: Int, manual: Bool) async {
        guard epoch == version else { return }
        if manual { status = "جاري تحديث الشارت" }
        do {
            let latest = try await BreakoutAPI.shared.candles(
                symbol: symbol, timeframe: timeframe, limit: 500
            )
            guard epoch == version && !Task.isCancelled else { return }
            if !latest.isEmpty {
                // Do not overwrite a more recent WebSocket update for the forming bar.
                let freshStream = connected && latestUpdate.map { Date().timeIntervalSince($0) < 6 } == true
                let last = candles.last
                var merged = latest
                if freshStream, let last,
                   let index = merged.firstIndex(where: { $0.openTime == last.openTime }),
                   last.volume >= merged[index].volume {
                    merged[index] = last
                }
                candles = merged
                latestUpdate = Date()
                connected = lastSocketEvent.map { Date().timeIntervalSince($0) < 15 } ?? false
                status = connected ? "مباشر" : (manual ? "تم تحديث الشارت" : "تحديث دوري")
            }
        } catch {
            guard epoch == version && manual else { return }
            status = "تعذّر التحديث: \(error.localizedDescription)"
        }
    }

    private func receiveSocket(_ data: Data, version: Int) {
        guard epoch == version,
              let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              object["e"] as? String == "kline",
              object["s"] as? String == symbol,
              let k = object["k"] as? [String: Any],
              k["i"] as? String == timeframe.rawValue,
              let start = (k["t"] as? NSNumber)?.int64Value,
              let end = (k["T"] as? NSNumber)?.int64Value,
              let open = Double(k["o"] as? String ?? ""),
              let high = Double(k["h"] as? String ?? ""),
              let low = Double(k["l"] as? String ?? ""),
              let close = Double(k["c"] as? String ?? ""),
              let volume = Double(k["v"] as? String ?? ""),
              let quote = Double(k["q"] as? String ?? "") else { return }

        let incoming = BreakoutCandle(openTime: start, closeTime: end,
                                     open: open, high: high, low: low, close: close,
                                     volume: volume, quoteVolume: quote)
        guard incoming.valid else { return }
        if let index = candles.firstIndex(where: { $0.openTime == incoming.openTime }) {
            if incoming.volume >= candles[index].volume { candles[index] = incoming }
        } else if candles.last.map({ incoming.openTime > $0.openTime }) ?? true {
            candles.append(incoming)
            if candles.count > 500 { candles.removeFirst(candles.count - 500) }
        }
        connected = true
        lastSocketEvent = Date()
        latestUpdate = Date()
        status = "مباشر"
    }
}

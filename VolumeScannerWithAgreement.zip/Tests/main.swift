import Foundation

func approx(_ actual: Double?, _ expected: Double, line: Int = #line) {
    guard let actual, abs(actual - expected) < 0.00001 else {
        fatalError("Line \(line): got \(String(describing: actual)), expected \(expected)")
    }
}

let anchor: Int64 = 1_800_000_000_000 // divisible by five minutes
precondition(anchor % VolumeMath.fiveMinutes == 0)
var bars: [Int64: Double] = [:]

for i in 0..<288 {
    bars[anchor - Int64(288 - i) * VolumeMath.fiveMinutes] = 1_000
}

// Last hour: 12 x 25,000; prior hour: 12 x 4,000 = +252,000.
for i in 0..<12 {
    bars[anchor - Int64(12 - i) * VolumeMath.fiveMinutes] = 25_000
    bars[anchor - Int64(24 - i) * VolumeMath.fiveMinutes] = 4_000
}
var delta = VolumeMath.differences(bars, anchorOpen: anchor)
approx(delta.oneHour, 252_000)
precondition(delta.qualifies)

// Consecutive 4-hour windows: 48 x 40,000 vs 48 x 2,000.
for i in 0..<96 {
    bars[anchor - Int64(96 - i) * VolumeMath.fiveMinutes] = i >= 48 ? 40_000 : 2_000
}
delta = VolumeMath.differences(bars, anchorOpen: anchor)
approx(delta.fourHours, 1_824_000)
precondition(delta.qualifies)

// Consecutive 12-hour windows: 144 x 30,000 vs 144 x 1,000.
for i in 0..<288 {
    bars[anchor - Int64(288 - i) * VolumeMath.fiveMinutes] = i >= 144 ? 30_000 : 1_000
}
delta = VolumeMath.differences(bars, anchorOpen: anchor)
approx(delta.twelveHours, 4_176_000)
precondition(delta.qualifies)

// Without a candle in a comparison, show nil, not a misleading zero.
bars.removeValue(forKey: anchor - VolumeMath.fiveMinutes)
delta = VolumeMath.differences(bars, anchorOpen: anchor)
precondition(delta.oneHour == nil)
precondition(delta.fourHours == nil)
precondition(delta.twelveHours == nil)

// Negative volumes are shown as signed differences but never trigger a shortlist.
for i in 0..<288 {
    bars[anchor - Int64(288 - i) * VolumeMath.fiveMinutes] = i >= 144 ? 1_000 : 30_000
}
delta = VolumeMath.differences(bars, anchorOpen: anchor)
approx(delta.twelveHours, -4_176_000)
precondition(!delta.qualifies)
print("PASS: 1h / 4h / 12h comparison, thresholds, missing bars, negative deltas")

// Trendline breakout port: ATR(24), 1.4 multiplier and last N closed bars.
let sampleCandles: [BreakoutCandle] = (0..<360).map { i in
    let time = Int64(i) * 14_400_000
    let midpoint = 100 + 7 * sin(Double(i) * 0.115)
        + 3 * sin(Double(i) * 0.041) + Double(i) * 0.013
    let close = midpoint + 0.43 * sin(Double(i) * 0.38)
    let open = midpoint - 0.3 * cos(Double(i) * 0.20)
    return BreakoutCandle(
        openTime: time, closeTime: time + 14_399_999,
        open: open, high: max(open, close) + 0.7,
        low: min(open, close) - 0.7, close: close,
        volume: 1_000 + Double(i), quoteVolume: close * (1_000 + Double(i))
    )
}
let series = BreakoutMath.trendlines(sampleCandles)
precondition(series.count == sampleCandles.count)
precondition(series[0].highAnchor == nil && series[0].lowAnchor == nil)
precondition(series.contains(where: { $0.highAnchor != nil }))
precondition(series.contains(where: { $0.lowAnchor != nil }))
precondition(BreakoutMath.rma(Array(repeating: 4.0, count: 50), period: 24).allSatisfy { !$0.isFinite || abs($0 - 4) < 0.000001 })
let em = BreakoutMath.ema([2, 4, 8], length: 3)
precondition(abs(em[0] - 2) < 0.000001 && abs(em[1] - 3) < 0.000001 && abs(em[2] - 5.5) < 0.000001)
let last3 = BreakoutMath.hits(sampleCandles, symbol: "TESTUSDT", timeframe: .h4, lastClosedWindow: 3)
precondition(last3.allSatisfy { $0.age <= 2 })
let last50 = BreakoutMath.hits(sampleCandles, symbol: "TESTUSDT", timeframe: .h4, lastClosedWindow: 50)
precondition(last3.allSatisfy { row in last50.contains { $0.id == row.id } })
let indicators = BreakoutMath.indicators(sampleCandles)
precondition(indicators.ema50.count == 360 && indicators.macd.count == 360)
precondition(indicators.histogram.allSatisfy(\.isFinite))
print("PASS: LuxAlgo 24/1.4/ATR trendlines, closed-window signals, EMA50/100/200, MACD")

// Agreement tab: exactly the intersection of the saved volume shortlist and
// saved breakout results; duplicates on one timeframe pick the newest signal.
func sampleHit(_ symbol: String, _ frame: BreakoutTimeframe, _ direction: BreakoutDirection,
               _ time: Int64) -> BreakoutHit {
    BreakoutHit(symbol: symbol, timeframe: frame, direction: direction,
                barTime: time - 1000, closeTime: time, price: 1.24,
                level: 1.22, age: 0)
}
func sampleVolume(_ symbol: String, _ d1: Double) -> MarketRow {
    MarketRow(symbol: symbol, coin: String(symbol.dropLast(4)), direct24h: 1_800_000,
              differences: VolumeDifferences(oneHour: d1, fourHours: -10_000, twelveHours: 600_000))
}
let a = sampleVolume("AXSUSDT", 300_000)
let b = sampleVolume("DOGEUSDT", 500_000)
let outsider = sampleHit("LINKUSDT", .h4, .up, 20_000)
let axOld = sampleHit("AXSUSDT", .h4, .up, 10_000)
let axNew = sampleHit("AXSUSDT", .h4, .down, 30_000)
let axWeekly = sampleHit("AXSUSDT", .w1, .up, 40_000)
let doge = sampleHit("DOGEUSDT", .d1, .up, 80_000)
let entries = AgreementMath.matches(shortlist: [a, b], breakouts: [outsider, axOld, axNew, axWeekly, doge])
precondition(entries.count == 2)
precondition(entries.map(\.id) == ["DOGEUSDT", "AXSUSDT"])
precondition(entries[1].timeframes.count == 2)  // 4h + 1w, not duplicate 4h
precondition(entries[1].timeframes.map(\.timeframe) == [.h4, .w1])
precondition(entries[1].timeframes[0].direction == .down) // newer 4h replaces older 4h
precondition(entries[1].latest.id == axWeekly.id)
precondition(AgreementMath.matches(shortlist: [a], breakouts: [doge, outsider]).isEmpty)
precondition(AgreementMath.matches(shortlist: [b], breakouts: [axNew, doge]).map(\.id) == ["DOGEUSDT"])
precondition(AgreementMath.matches(shortlist: [], breakouts: [doge, axNew]).isEmpty)
precondition(AgreementMath.matches(shortlist: [a, b], breakouts: []).isEmpty)
print("PASS: agreement intersection, multiple timeframes, newest per frame, removals from either source")
